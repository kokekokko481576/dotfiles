## `azimuth_teleop` パッケージ

`azimuth_teleop`は、ゲームコントローラーを用いてAzimuth船をリアルタイムに操縦するためのパッケージです。手動/自動モードの切り替えや緊急停止などの安全機能も備えています。

### システムアーキテクチャ

`teleop.launch.py`で起動されるシステムは、以下の図のように連携して動作します。

```mermaid
graph TD
    subgraph "🎮 Controller"
        A[Joystick]
    end

    subgraph "💻 ROS 2 Nodes"
        A --> B[joy_node];
        B -- "/joy
(sensor_msgs/Joy)" --> C[manual_teleop_node];
        C -- "/cmd_vel_joy
(geometry_msgs/Twist)" --> D[twist_mux];
        C -- "/cmd_vel_emergency
(geometry_msgs/Twist)" --> D;
        subgraph "Future Autonomy"
            E[e.g. nav2_node] -- "/cmd_vel_auto
(geometry_msgs/Twist)" --> D;
        end
        D -- "/cmd_vel
(geometry_msgs/Twist)" --> F[azimuth_commander_node];
        F -- "/azimuth_command
(azimuth_teleop/AzimuthControl)" --> G[f7_interface_node];
    end

    subgraph "🚤 Ship Hardware"
        G -. UDP Packet .-> H((STM32 F7));
    end

    style E fill:#eee,stroke:#333,stroke-dasharray: 5 5
```

### コンポーネント

#### ノード (Nodes)

- **`joy_node`**: PCに接続されたジョイスティックの入力を検知し、`/joy`トピックとして発行します。
- **`manual_teleop_node`**: `/joy`を購読し、スティック操作を線形・角速度指令 (`/cmd_vel_joy`) に変換します。また、特定のボタン操作で**手動/自動モードの切り替え**や**緊急停止**指令も発行する、操縦のコアとなるノードです。
- **`twist_mux`**: 複数の速度指令ソースをインテリジェントに多重化（multiplex）します。手動操縦 (`/cmd_vel_joy`)、自律航行 (`/cmd_vel_auto`)、緊急停止 (`/cmd_vel_emergency`) といった複数の指令を受け取り、設定された優先度に基づい​​て単一の指令 `/cmd_vel` を選択して出力します。これにより、安全な操縦の切り替えが実現されます。
- **`azimuth_commander_node`**: システムの**頭脳**。`/cmd_vel`で与えられた抽象的な速度指令（例: 前進、旋回）を、船の物理モデル（スラスター配置など）に基づいて、各スラスターが実行すべき具体的なRPMと角度の指令に変換します。結果はカスタムメッセージ `/azimuth_command` として発行されます。
- **`f7_interface_node`**: ROSの世界と物理ハードウェアの**架け橋**。`/azimuth_command`を購読し、その内容をSTM32 F7マイコンが解釈できるUDPパケット形式に変換してネットワーク経由で送信します。
- **`dp_allocator_node`**: `/cmd_vel` を購読し、動的位置決め（DP）のためのスラスター配分計算を行います。（現在プレースホルダー）

#### 主要トピック (Topics)

- `/joy` (`sensor_msgs/Joy`): コントローラーの生データ。
- `/cmd_vel_joy` (`geometry_msgs/Twist`): 手動操縦ノードが発行する速度指令。
- `/cmd_vel_emergency` (`geometry_msgs/Twist`): 緊急停止用のゼロ速度指令。
- `/cmd_vel` (`geometry_msgs/Twist`): `twist_mux`によって選択された、最終的な速度指令。
- `/azimuth_command` (`azimuth_teleop/msg/AzimuthControl`): 各スラスターへの具体的なRPM・角度指令。

### 設定ファイル

操縦の挙動は`azimuth_teleop/config`内のYAMLファイルで調整できます。

- **`8bitdo.yaml`, `hori.yaml`**: 各コントローラーのボタン・軸マッピング。`teleop.launch.py`が起動時に自動で検出し、適切な設定を読み込みます。
- **`teleop_params.yaml`**:
    - `manual_teleop_node`: 最高速度や最大旋回速度。
    - `azimuth_commander_node`: スラスター間の距離など、船の物理パラメータ。
- **`twist_mux.yaml`**: 各操縦ソースの優先度やタイムアウト設定。