# `manual_teleop_node.cpp` 超詳細解説

## 1. ファイル概要

このファイルは、ジョイスティック入力に基づいて艦船を手動で操縦するためのROS 2ノードです。

`/joy` トピックを購読し、ジョイスティックの軸とボタンのマッピングをROSパラメータから動的に読み込みます。読み取った入力は、Twistメッセージ（線形速度と角速度の指令）に変換され、`/cmd_vel_joy` トピックとしてパブリッシュされます。

さらに、自律モード（Station Keeping）への切り替え、手動操作による自律モードのオーバーライド（割り込み解除）、そして緊急停止機能も提供する、操縦の中核を担うノードです。

## 2. インクルード

このノードが必要とするヘッダーファイルです。

```cpp
#include <cmath>
#include <vector>

#include "geometry_msgs/msg/twist.hpp"
#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/joy.hpp"
#include "std_msgs/msg/bool.hpp"
```

-   `#include <cmath>`: `std::abs`（絶対値）を計算するために使用します。スティックの入力が一定の閾値を超えたかを判定する際に必要です。
-   `#include <vector>`: `std::vector` を使用するためにインクルードしますが、このファイルでは直接的には使われていません（`sensor_msgs::msg::Joy` の内部で使用されています）。
-   `#include "geometry_msgs/msg/twist.hpp"`: 速度指令（並進速度 `linear` と回転速度 `angular`）を送るための `Twist` メッセージ型を定義しています。
-   `#include "rclcpp/rclcpp.hpp"`: ROS 2のC++クライアントライブラリのコア機能（ノード、パブリッシャー、サブスクライバーなど）を提供します。`rclcpp::Node` を継承するために必須です。
-   `#include "sensor_msgs/msg/joy.hpp"`: ジョイスティックからの入力データ（軸 `axes` とボタン `buttons` の状態）を受け取るための `Joy` メッセージ型を定義しています。
-   `#include "std_msgs/msg/bool.hpp"`: 自律モードのON/OFFを切り替えるための単純な `Bool` メッセージ型（`true` または `false` の値を保持）を定義しています。

## 3. `ManualTeleopNode` クラス

ジョイスティックからの入力を速度指令に変換し、モード管理を行うためのメインクラスです。`rclcpp::Node` をパブリックに継承することで、ROS 2のノードとしての機能を使えるようになります。

```cpp
class ManualTeleopNode : public rclcpp::Node {
// ... クラス定義 ...
};
```

### 3.1. コンストラクタ `ManualTeleopNode()`

ノードが初期化されるときに一度だけ呼ばれるコンストラクタです。ここで、ノードの基本的な設定（パラメータ、Pub/Subなど）をすべて行います。

#### 3.1.1. ノード名とメンバ変数の初期化

```cpp
  ManualTeleopNode() : Node("manual_teleop_node"), is_auto_mode_(false) {
```

-   `Node("manual_teleop_node")`: 親クラスである `rclcpp::Node` のコンストラクタを呼び出し、ROSネットワーク上でのノード名を `"manual_teleop_node"` に設定します。
-   `is_auto_mode_(false)`: このクラスのメンバ変数である `is_auto_mode_` を `false` で初期化します。これは、ノード起動時は必ず手動モードから開始することを意味します。

#### 3.1.2. ROSパラメータの宣言

このノードの挙動を外部のYAMLファイルから柔軟に変更できるように、使用する全てのパラメータを `declare_parameter` を使って宣言します。

```cpp
    // === パラメータ宣言 ===
    // このノードの挙動は、launchファイルから渡されるYAMLファイルによって詳細に設定されます。

    // --- 共通パラメータ ---
    this->declare_parameter<double>("max_linear_speed", 1.0);  // [m/s]
    this->declare_parameter<double>("max_angular_speed", 1.57);  // [rad/s]
```

-   `this->declare_parameter<double>("max_linear_speed", 1.0);`: `max_linear_speed` という名前の `double` 型パラメータを宣言し、もしYAMLファイルで指定されなかった場合のデフォルト値を `1.0` [m/s] に設定します。
-   `this->declare_parameter<double>("max_angular_speed", 1.57);`: 同様に、最大角速度のパラメータを宣言します。デフォルト値は `1.57` [rad/s] (約90 deg/s) です。

```cpp
    // --- 軸マッピング (-1で無効) ---
    this->declare_parameter<int>("axis_linear_x", -1);   // 前後移動
    this->declare_parameter<int>("axis_linear_y", -1);   // 横移動
    this->declare_parameter<int>("axis_angular_z", -1);  // 旋回
```

-   `this->declare_parameter<int>("axis_...", -1);`: 各種の移動・旋回操作を、ジョイスティックの `axes` 配列のどのインデックスに割り当てるかを `int` 型で宣言します。デフォルト値の `-1` は、その軸マッピングが無効であることを示す特別な値です。

```cpp
    // --- ボタンマッピング (-1で無効) ---
    this->declare_parameter<int>("button_angular_z_positive", -1);
    this->declare_parameter<int>("button_angular_z_negative", -1);
    this->declare_parameter<int>("button_mode_toggle", -1);
    this->declare_parameter<int>("button_emergency_1", -1);
    this->declare_parameter<int>("button_emergency_2", -1);
```

-   `this->declare_parameter<int>("button_...", -1);`: 各種のボタン操作を、ジョイスティックの `buttons` 配列のどのインデックスに割り当てるかを `int` 型で宣言します。こちらもデフォルトは `-1` (無効) です。

```cpp
    // --- 速度スケーリング --- 
    this->declare_parameter<double>("scale_linear", 1.0);
    this->declare_parameter<double>("scale_angular", 1.0);
```

-   `this->declare_parameter<double>("scale_...", 1.0);`: 計算された速度指令に乗算される係数を宣言します。デフォルトは `1.0` (100%) です。例えば `0.5` に設定すると、通常の半分の速度になります。

#### 3.1.3. サブスクライバーとパブリッシャーの作成

ノード間の通信（トピックの送受信）を行うためのサブスクライバーとパブリッシャーを作成します。

```cpp
    // === サブスクライバーとパブリッシャーの作成 ===
    joy_sub_ = this->create_subscription<sensor_msgs::msg::Joy>(
        "joy", 10,
        std::bind(&ManualTeleopNode::joy_callback, this,
                  std::placeholders::_1));
```

-   `joy_sub_ = this->create_subscription<...>(...)`: `/joy` トピックを購読するためのサブスクライバーを作成し、メンバ変数 `joy_sub_` に格納します。
    -   `<sensor_msgs::msg::Joy>`: 受信するメッセージの型を指定します。
    -   `"joy"`: 購読するトピック名です。
    -   `10`: Quality of Service (QoS) の設定で、メッセージを10個まで保持するバッファ（キュー）のサイズです。
    -   `std::bind(...)`: メッセージを受信するたびに呼び出されるコールバック関数を指定します。ここでは、`ManualTeleopNode` クラスのメンバ関数である `joy_callback` を指定しています。`std::placeholders::_1` は、受信したメッセージが `joy_callback` の第一引数として渡されることを示します。

```cpp
    cmd_vel_pub_ =
        this->create_publisher<geometry_msgs::msg::Twist>("/cmd_vel_joy", 10);
    auto_mode_pub_ = this->create_publisher<std_msgs::msg::Bool>(
        "/engage_station_keeping", 10);
    emergency_stop_pub_ = this->create_publisher<geometry_msgs::msg::Twist>(
        "/cmd_vel_emergency", 10);
```

-   `..._pub_ = this->create_publisher<...>(...)`: 指定したトピックにメッセージを配信するためのパブリッシャーを3つ作成し、それぞれのメンバ変数に格納します。
    -   `cmd_vel_pub_`: 手動操作時の速度指令 (`Twist` 型) を `/cmd_vel_joy` トピックにパブリッシュします。
    -   `auto_mode_pub_`: 自律モードの開始/終了要求 (`Bool` 型) を `/engage_station_keeping` トピックにパブリッシュします。
    -   `emergency_stop_pub_`: 緊急停止用のゼロ速度指令 (`Twist` 型) を `/cmd_vel_emergency` トピックにパブリッシュします。

```cpp
    RCLCPP_INFO(
        this->get_logger(),
        "Manual Teleop Node has been started with parameter-based mapping.");
  }
```

-   `RCLCPP_INFO(...)`: コンストラクタの最後に、ノードが正常に起動したことを示す情報ログをコンソールに出力します。

### 3.2. `joy_callback()` 関数

`/joy` トピックからメッセージを受信するたびに実行される、このノードの心臓部です。処理は **優先度の高い順** （緊急停止 > モード切替 > 手動操作）に実行されます。

#### 3.2.1. パラメータの実行時取得

```cpp
  void joy_callback(const sensor_msgs::msg::Joy::SharedPtr msg) {
    // --- パラメータの取得 ---
    const int axis_linear_x = this->get_parameter("axis_linear_x").as_int();
    const int axis_linear_y = this->get_parameter("axis_linear_y").as_int();
    // ... (他のパラメータも同様に取得) ...
```

-   `const sensor_msgs::msg::Joy::SharedPtr msg`: 受信した `Joy` メッセージが、スマートポインタ `SharedPtr` として `msg` 引数に渡されます。
-   `this->get_parameter(...).as_int()`: コールバック関数が呼ばれるたびに、現在のROSパラメータを `get_parameter` で取得します。これにより、`rqt_reconfigure` などを使ってノード実行中にパラメータを変更しても、即座に挙動に反映させることができます。

#### 3.2.2. 安全チェック（バウンドチェック）

YAMLファイルに設定された軸・ボタンのIDが、実際にコントローラーから送られてきたデータ配列のサイズを超えていないかを確認します。

```cpp
    // --- 安全チェック ---
    auto check_bounds = [&](int id, size_t size, const std::string& type) {
      if (id >= 0 && static_cast<size_t>(id) >= size) {
        RCLCPP_ERROR_ONCE(this->get_logger(),
                          "Parameter %s_id: %d is out of bounds for joy "
                          "message size %zu. Check controller config.",
                          type.c_str(), id, size);
        return false;
      }
      return true;
    };
```

-   `auto check_bounds = [&](...) { ... };`: `check_bounds` という名前のラムダ式（簡易的な関数）を定義しています。`[&]` は、このラムダ式がクラスのメンバ変数にアクセスできることを示します。
-   `if (id >= 0 && static_cast<size_t>(id) >= size)`: パラメータで指定されたID (`id`) が `0` 以上（つまり有効な設定）であり、かつ、受信したJoyメッセージの配列サイズ (`size`) 以上であるか（つまり範囲外か）をチェックします。
-   `RCLCPP_ERROR_ONCE(...)`: もし範囲外であれば、エラーメッセージを **一度だけ** 表示します。`_ONCE` をつけることで、同じエラーがコンソールを埋め尽くすのを防ぎます。
-   `return false;`: チェックに失敗したことを示します。

```cpp
    if (!check_bounds(axis_linear_x, msg->axes.size(), "axis_linear_x") ||
        !check_bounds(axis_linear_y, msg->axes.size(), "axis_linear_y") ||
        // ... (他のすべてのマッピングに対してチェック) ...
       ) {
      return;  // エラーがあればこの周期の処理を中断
    }
```

-   定義した `check_bounds` ラムダ式を、宣言したすべての軸・ボタンマッピングに対して実行します。
-   `||` (OR) で繋がれているため、どれか一つでもチェックに失敗 (`false` を返す) すれば、`if` 文全体が `true` になります。
-   `return;`: `if` 文が `true` になった場合、つまり設定ミスがあった場合は、安全のために `joy_callback` 関数の処理をこの場で中断し、次のJoyメッセージを待ちます。

#### 3.2.3. 緊急停止ロジック (最優先)

```cpp
    // --- 緊急停止ロジック (最優先) ---
    if (btn_emergency_1 >= 0 && btn_emergency_2 >= 0 &&
        msg->buttons[btn_emergency_1] == 1 &&
        msg->buttons[btn_emergency_2] == 1) {
      auto stop_msg = std::make_unique<geometry_msgs::msg::Twist>();
      emergency_stop_pub_->publish(std::move(stop_msg));
      RCLCPP_WARN(this->get_logger(), "EMERGENCY STOP ACTIVATED!");
      return;  // 緊急停止が作動したら、他の操作はすべて無視
    }
```

-   `if (btn_emergency_1 >= 0 && btn_emergency_2 >= 0 && ...)`: まず、緊急停止用のボタン1と2が両方ともYAMLファイルで設定されているか（IDが-1でないか）を確認します。
-   `&& msg->buttons[btn_emergency_1] == 1 && msg->buttons[btn_emergency_2] == 1)`: 次に、その2つのボタンが **同時に** 押されているか（値が `1` であるか）を確認します。
-   **もし条件がすべて True ならば**:
    -   `auto stop_msg = std::make_unique<geometry_msgs::msg::Twist>();`: 中身がすべてゼロで初期化された `Twist` メッセージを生成します。
    -   `emergency_stop_pub_->publish(std::move(stop_msg));`: 生成したゼロ速度指令を、最高優先度の `/cmd_vel_emergency` トピックにパブリッシュします。
    -   `RCLCPP_WARN(...)`: 緊急停止が作動したことを示す警告ログをコンソールに出力します。
    -   `return;`: 最優先の処理であるため、これ以降のコールバック内の処理（モード切替や通常操作）をすべて無視して関数を終了します。

#### 3.2.4. モード切替ロジック

```cpp
    // --- モード切替ロジック ---
    if (btn_mode_toggle >= 0 && msg->buttons[btn_mode_toggle] == 1 &&
        !is_auto_mode_) {
      is_auto_mode_ = true;
      auto engage_msg = std::make_unique<std_msgs::msg::Bool>();
      engage_msg->data = true;
      auto_mode_pub_->publish(std::move(engage_msg));
      RCLCPP_INFO(this->get_logger(), "Engaging Station Keeping Mode!");
    }
```

-   `if (btn_mode_toggle >= 0 && ...)`: モード切替ボタンが設定されているかを確認します。
-   `&& msg->buttons[btn_mode_toggle] == 1`: モード切替ボタンが押されたかを確認します。
-   `&& !is_auto_mode_`: **現在が手動モードである**ことを確認します。これにより、自律モード中にボタンを連打しても、何度も同じ指令が送られるのを防ぎます。
-   **もし条件がすべて True ならば**:
    -   `is_auto_mode_ = true;`: ノードの状態を「自律モード」に切り替えます。
    -   `auto engage_msg = ...; engage_msg->data = true;`: `true` の値を持つ `Bool` メッセージを作成します。
    -   `auto_mode_pub_->publish(...)`: 作成したメッセージを `/engage_station_keeping` トピックにパブリッシュし、他のノード（DPノードなど）に自律モードを開始するよう要求します。

#### 3.2.5. 手動操作によるモード解除（オーバーライド）

安全のための重要な機能です。自律モード中にオペレーターが意図的に操縦しようとした場合、即座に手動モードに戻します。

```cpp
    // --- 手動操作によるモード解除 ---
    bool is_overriding =
        (axis_linear_x >= 0 && std::abs(msg->axes[axis_linear_x]) > 0.1) ||
        (axis_linear_y >= 0 && std::abs(msg->axes[axis_linear_y]) > 0.1) ||
        (axis_angular_z >= 0 && std::abs(msg->axes[axis_angular_z]) > 0.1) ||
        (btn_angular_pos >= 0 && msg->buttons[btn_angular_pos] == 1) ||
        (btn_angular_neg >= 0 && msg->buttons[btn_angular_neg] == 1);
```

-   `bool is_overriding = ...`: 手動操作が行われたかどうかを示すフラグ `is_overriding` を定義します。
-   `(axis_linear_x >= 0 && std::abs(msg->axes[axis_linear_x]) > 0.1)`: 前後移動の軸が設定されており、かつ、その軸の入力値の絶対値が `0.1` を超えているか（＝スティックが意図的に倒されているか）をチェックします。`0.1` という閾値（デッドバンド）を設けることで、スティックのわずかな遊び（ドリフト）で意図せずモードが解除されるのを防ぎます。
-   `||`: OR条件。前後、左右、旋回のいずれかのスティックが操作されるか、または旋回ボタンが押された場合に、`is_overriding` フラグが `true` になります。

```cpp
    if (is_auto_mode_ && is_overriding) {
      is_auto_mode_ = false;
      auto engage_msg = std::make_unique<std_msgs::msg::Bool>();
      engage_msg->data = false;
      auto_mode_pub_->publish(std::move(engage_msg));
      RCLCPP_INFO(this->get_logger(),
                  "Disengaging Station Keeping Mode! Manual override.");
    }
```

-   `if (is_auto_mode_ && is_overriding)`: 現在が自律モードであり、かつ、上記で定義した手動操作が行われた場合に、このブロックが実行されます。
-   **もし条件が True ならば**:
    -   `is_auto_mode_ = false;`: ノードの状態を「手動モード」に戻します。
    -   `auto engage_msg = ...; engage_msg->data = false;`: `false` の値を持つ `Bool` メッセージを作成します。
    -   `auto_mode_pub_->publish(...)`: 作成したメッセージを `/engage_station_keeping` トピックにパブリッシュし、他のノードに自律モードを終了するよう伝えます。

#### 3.2.6. 手動操作ロジック

ジョイスティックの入力に基づいて速度指令 (`Twist` メッセージ) を生成し、パブリッシュします。

```cpp
    // --- 手動操作ロジック ---
    if (!is_auto_mode_) {
      auto twist_msg = std::make_unique<geometry_msgs::msg::Twist>();
      const double max_linear = this->get_parameter("max_linear_speed").as_double();
      // ... (他のパラメータも取得) ...
```

-   `if (!is_auto_mode_)`: 現在が手動モードの場合にのみ、このブロック内の処理を実行します。
-   `auto twist_msg = ...`: パブリッシュするための `Twist` メッセージを生成します。
-   `const double max_linear = ...`: 計算に必要なパラメータを `get_parameter` で取得します。

```cpp
      // 直進・並進 (ROS標準: 前進がX+、左方向がY+)
      // YAMLのコメント通り、多くのゲームパッドは上/左が-1.0のため、符号を反転させて直感的な操作を実現
      if (axis_linear_x >= 0) {
        twist_msg->linear.x =
            -msg->axes[axis_linear_x] * max_linear * scale_linear;
      }
      if (axis_linear_y >= 0) {
        twist_msg->linear.y =
            -msg->axes[axis_linear_y] * max_linear * scale_linear;
      }
```

-   `if (axis_linear_x >= 0)`: 前後移動の軸が設定されている場合のみ、処理を実行します。
-   `twist_msg->linear.x = -msg->axes[...] * ...`: 速度を計算します。
    -   `-msg->axes[axis_linear_x]`: 多くのゲームコントローラーでは、スティックを「上」に倒すと値が `-1.0` になります。ROSの座標系では「前方」が `X+` なので、直感的な操作（上を倒したら前進）を実現するために、ここで符号を反転 (`-`) させています。
    -   `* max_linear`: 最大速度を掛け合わせます。
    -   `* scale_linear`: さらに速度スケールを掛け合わせます。

```cpp
      // 旋回
      if (axis_angular_z >= 0) {
        // 軸で旋回
        twist_msg->angular.z =
            -msg->axes[axis_angular_z] * max_angular * scale_angular;
      } else {
        // ボタンで旋回
        if (btn_angular_pos >= 0 && msg->buttons[btn_angular_pos] == 1) {
          twist_msg->angular.z = max_angular * scale_angular;
        } else if (btn_angular_neg >= 0 && msg->buttons[btn_angular_neg] == 1) {
          twist_msg->angular.z = -max_angular * scale_angular;
        }
      }
```

-   `if (axis_angular_z >= 0)`: 旋回用の「軸」が設定されている場合の処理です。計算方法は並進速度と同様です。
-   `else`: 旋回用の軸が設定されていない場合（`-1` の場合）は、代わりに「ボタン」で旋回するロジックを実行します。
    -   `if (btn_angular_pos >= 0 && ...)`: 右旋回ボタンが押されていれば、正の最大角速度を指令値とします。
    -   `else if (btn_angular_neg >= 0 && ...)`: 左旋回ボタンが押されていれば、負の最大角速度を指令値とします。

```cpp
      cmd_vel_pub_->publish(std::move(twist_msg));
    }
```

-   `cmd_vel_pub_->publish(...)`: 最終的に計算された `Twist` メッセージを、`/cmd_vel_joy` トピックにパブリッシュします。

### 3.3. メンバ変数

クラス内で状態を保持したり、ROSの機能（Pub/Sub）にアクセスしたりするための変数です。

```cpp
  // === メンバ変数 ===
  rclcpp::Subscription<sensor_msgs::msg::Joy>::SharedPtr joy_sub_;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_pub_;
  rclcpp::Publisher<std_msgs::msg::Bool>::SharedPtr auto_mode_pub_;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr emergency_stop_pub_;
  bool is_auto_mode_;
```

-   `..._sub_`, `..._pub_`: コンストラクタで作成したサブスクライバーとパブリッシャーのオブジェクトを保持します。`SharedPtr` は、複数の場所から安全にオブジェクトを共有するためのスマートポインタです。
-   `is_auto_mode_`: 現在のモード（`true`なら自律、`false`なら手動）を記憶しておくためのフラグ変数です。

## 4. `main` 関数

このプログラムのエントリーポイント（開始地点）です。

```cpp
int main(int argc, char* argv[]) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<ManualTeleopNode>());
  rclcpp::shutdown();
  return 0;
}
```

-   `rclcpp::init(argc, argv)`: ROS 2を初期化します。ROS関連の機能を使う前に必ず呼び出す必要があります。
-   `rclcpp::spin(std::make_shared<ManualTeleopNode>())`: `ManualTeleopNode` のインスタンスを作成し、ROS 2のイベントループを開始します。これにより、トピックの受信やタイマーの呼び出しなどが可能になります。`Ctrl+C` などでノードが終了するまで、この関数は処理をブロックし続けます。
-   `rclcpp::shutdown()`: `spin` が終了した後に、ROS 2のシステムをクリーンアップして終了します。
-   `return 0;`: プログラムが正常に終了したことを示します。