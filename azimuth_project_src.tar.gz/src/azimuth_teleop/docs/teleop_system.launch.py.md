# `teleop_system.launch.py` 超詳細解説

## 1. ファイル概要

このファイルは、`teleop.launch.py` とは異なる、よりシンプルで汎用的な構成のテレオペレーション（遠隔操作）システムを起動するためのROS 2の起動ファイルです。

`teleop.launch.py` が `manual_teleop_node` のようなこのプロジェクト専用に開発されたノードを起動するのに対し、この `teleop_system.launch.py` は、ROSで一般的に利用される**標準的なパッケージ**（`joy_linux`, `teleop_twist_joy`, `twist_mux`）のみを使ってシステムを構築します。

この起動ファイルは、以下のような目的で使用されることが考えられます。

-   **基本的な動作確認**: ROSの標準機能だけでジョイスティック操作が可能か、基本的なセットアップをテストする。
-   **問題の切り分け**: カスタムノード（`manual_teleop_node` など）に問題が発生した際に、原因がカスタムノードにあるのか、あるいはもっと基本的なROSの通信や `twist_mux` の設定にあるのかを切り分けるための比較対象として使用する。
-   **シンプルな代替システム**: モード切替などの高度な機能が不要で、単純な操縦さえできれば良い場合の代替システムとして使用する。

## 2. `generate_launch_description()` 関数

起動するノードのリストを定義し、`LaunchDescription` オブジェクトとして返します。このファイルでは、3つの標準的なROSノードを起動します。

### 2.1. パス設定

```python
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    # パッケージのconfigフォルダへのパスを取得
    pkg_share = get_package_share_directory('azimuth_teleop')

    # 各設定ファイルのフルパスを作成
    joy_config_filepath = os.path.join(pkg_share, 'config', 'joy_mapping.yaml')
    twist_mux_config_filepath = os.path.join(pkg_share, 'config', 'twist_mux.yaml')
```

-   `pkg_share = get_package_share_directory('azimuth_teleop')`: `azimuth_teleop` パッケージの `share` ディレクトリへの絶対パスを取得します。
-   `joy_config_filepath = os.path.join(...)`: `teleop_twist_joy` ノードが使用するボタン・軸マッピングファイル `joy_mapping.yaml` への絶対パスを作成します。
-   `twist_mux_config_filepath = os.path.join(...)`: `twist_mux` ノードが使用する設定ファイル `twist_mux.yaml` への絶対パスを作成します。

### 2.2. ノード構成

```python
    return LaunchDescription([
        // ... ノード定義 ...
    ])
```

#### 2.2.1. ノード①: `joy_linux_node`

```python
        # --- ノード①: joy_node ---
        # コントローラーの物理的な入力を/joyトピックに発行する
        Node(
            package='joy_linux',
            executable='joy_linux_node',
            name='joy_linux_node',
            parameters=[{'dev': '/dev/input/js0'}]
        ),
```

-   **パッケージ**: `joy_linux`
-   **実行ファイル**: `joy_linux_node`
-   **役割**: Linuxのジョイスティックデバイス（`/dev/input/js*`）からの物理的な入力を読み取り、ROSの標準的な `sensor_msgs/msg/Joy` メッセージとして `/joy` トピックにパブリッシュします。
-   **パラメータ**: `parameters=[{'dev': '/dev/input/js0'}]`
    -   `dev`: 使用するデバイスファイルを `/dev/input/js0` に**固定**しています。`teleop.launch.py` のようなコントローラーの自動検出機能はありません。

#### 2.2.2. ノード②: `teleop_node` (from `teleop_twist_joy`)

```python
        # --- ノード②: teleop_node ---
        # /joyトピックを購読し、Twistメッセージに変換する
        Node(
            package='teleop_twist_joy',
            executable='teleop_node',
            name='teleop_twist_joy_node',
            parameters=[joy_config_filepath],
            remappings=[('/cmd_vel', '/cmd_vel_joy')] # ★★★ 超重要ポイント！ ★★★
        ),
```

-   **パッケージ**: `teleop_twist_joy`
-   **実行ファイル**: `teleop_node`
-   **役割**: `/joy` トピックを購読し、設定ファイル（この場合は `joy_mapping.yaml`）に基づいて、ジョイスティックのどの軸やボタンがどの速度指令（前後、左右、旋回）に対応するかを解釈し、`geometry_msgs/msg/Twist` メッセージに変換してパブリッシュします。
-   **パラメータ**: `parameters=[joy_config_filepath]`
    -   `joy_mapping.yaml` を読み込み、ボタン・軸のマッピングを決定します。
-   **`remappings=[('/cmd_vel', '/cmd_vel_joy')]` (超重要ポイント！)**
    -   このノードは、デフォルトでは `/cmd_vel` というトピック名で `Twist` メッセージをパブリッシュします。
    -   しかし、このシステムでは `twist_mux` が最終的な `/cmd_vel` を出力する役割を担っています。もしこのノードが `/cmd_vel` に出力してしまうと、`twist_mux` の出力と衝突したり、意図しないループが発生する可能性があります。
    -   そこで `remappings` を使って、出力先のトピック名を `/cmd_vel_joy` に強制的に変更しています。これにより、このノードからの出力は `twist_mux` への入力の一つとして明確に区別されます。

#### 2.2.3. ノード③: `twist_mux`

```python
        # --- ノード③: twist_mux ---
        # 複数のTwistメッセージをまとめて、最終的な/cmd_velとして出力する
        Node(
            package='twist_mux',
            executable='twist_mux',
            name='twist_mux',
            parameters=[twist_mux_config_filepath],
            remappings=[('/cmd_vel_out', '/cmd_vel')]
        ),
```

-   **パッケージ**: `twist_mux`
-   **実行ファイル**: `twist_mux`
-   **役割**: 複数のソース（この場合は `/cmd_vel_joy` や、将来的には自律航行ノードからの `/cmd_vel_auto` など）からの `Twist` メッセージを受け取り、優先度に基づいて一つを選択し、最終的な船の速度指令としてパブリッシュします。
-   **パラメータ**: `parameters=[twist_mux_config_filepath]`
    -   `twist_mux.yaml` を読み込み、各入力トピックの優先度やタイムアウト時間を設定します。
-   **`remappings=[('/cmd_vel_out', '/cmd_vel')]`**
    -   `twist_mux` ノードは、デフォルトでは `/cmd_vel_out` という名前で最終的な速度指令をパブリッシュします。
    -   この設定により、出力トピック名をROSで標準的に使われる `/cmd_vel` に変更しています。これにより、`azimuth_commander_node` のような後段のノードが、設定変更なしで `twist_mux` の出力を購読できるようになります。