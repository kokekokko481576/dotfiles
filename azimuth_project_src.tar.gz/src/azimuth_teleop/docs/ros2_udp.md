# `ros2_udp.hpp` / `ros2_udp.cpp` 超詳細解説

## 1. ファイル概要

この2つのファイルはセットで、Linuxの標準的なソケットAPIを使いやすくするための「ラッパークラス」である `Ros2UDP` を定義・実装しています。

ソケットプログラミングは、アドレス構造体の設定、ネットワークバイトオーダーへの変換、システムコールの呼び出しなど、手続きが煩雑になりがちです。このクラスは、それらの詳細を内部に隠蔽（カプセル化）し、呼び出し側（このプロジェクトでは `f7_interface_node`）からは、まるでローカルの関数を呼び出すかのように、シンプルにUDPパケットの送受信（現在は送信のみ使用）を行えるように設計されています。

## 2. インクルード

UDP通信（ソケットプログラミング）に必要な、C言語標準のヘッダーファイル群です。

```cpp
// ros2_udp.hpp と ros2_udp.cpp の両方でインクルード
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#include <cstring>
#include <string>
```

-   `#include <sys/types.h>`: `socket` や `bind` などの関数で使われる `size_t` や `ssize_t` といった基本的なデータ型を定義しています。
-   `#include <sys/socket.h>`: `socket`, `sendto`, `bind` などの基本的なソケット関数と、`sockaddr` 構造体、`AF_INET`, `SOCK_DGRAM` などの定数を定義しています。
-   `#include <netinet/in.h>`: `sockaddr_in` 構造体や `htons` 関数など、インターネットプロトコル（IPv4）ファミリーに特有の定義が含まれています。
-   `#include <arpa/inet.h>`: `inet_addr` 関数など、IPアドレスの文字列形式（例: "192.168.1.1"）と32ビットのバイナリ表現を相互に変換するための関数を定義しています。
-   `#include <unistd.h>`: `close` 関数など、UNIX標準のシステムコールが含まれています。（このファイルでは直接使われていませんが、ソケットを閉じる際に必要となるため、一般的にインクルードされます）
-   `#include <string>`: C++の `std::string` クラスを使うために必要です。
-   `#include <cstring>`: C言語スタイルのメモリ操作関数（`memset`など）を使うために必要です。

## 3. `Ros2UDP` クラス定義 (`ros2_udp.hpp`)

`Ros2UDP` クラスのインターフェース（どのような機能があり、どうやって使うか）を定義したヘッダーファイルです。

```cpp
#ifndef _ROS2_UDP_HPP_
#define _ROS2_UDP_HPP_

// ... インクルード ...

class Ros2UDP {
 public:
  Ros2UDP(const std::string &f7_address, int f7_port);

  void udp_bind();

  ssize_t send_packet(uint8_t *packet, size_t size);

  ssize_t udp_recv(uint8_t *buf, size_t size);

 private:
  int sock;
  struct sockaddr_in f7_addr;
};

#endif
```

-   **インクルードガード**: `#ifndef _ROS2_UDP_HPP_` から `#endif` までの部分は「インクルードガード」と呼ばれ、このヘッダーファイルが複数のソースファイルからインクルードされた場合に、クラスの定義が二重に行われてコンパイルエラーになるのを防ぐための定型句です。
-   `class Ros2UDP { ... };`: `Ros2UDP` という名前のクラスを定義します。

### 3.1. `public` メンバ

クラスの外部から呼び出すことができる関数（メソッド）です。

-   `Ros2UDP(const std::string &f7_address, int f7_port);`: コンストラクタ。IPアドレスとポート番号を渡してオブジェクトを作成します。
-   `void udp_bind();`: ソケットに特定のポートを割り当てます（受信時に使用）。現在は使われていません。
-   `ssize_t send_packet(uint8_t *packet, size_t size);`: 実際にUDPパケットを送信する関数です。送信したバイト数を返します。
-   `ssize_t udp_recv(uint8_t *buf, size_t size);`: UDPパケットを受信する関数です。受信したバイト数を返します。現在は使われていません。

### 3.2. `private` メンバ

クラスの内部でのみ使用される変数です。外部から直接アクセスすることはできず、クラスのカプセル化を保証します。

-   `int sock;`: ソケットファイルディスクリプタ。OSがソケットを識別するために使う整数値です。`socket()` システムコールによって生成されます。
-   `struct sockaddr_in f7_addr;`: 送信先のIPアドレスやポート番号といった情報を保持するための構造体です。

## 4. `Ros2UDP` クラス実装 (`ros2_udp.cpp`)

ヘッダーファイルで宣言された各関数の、具体的な処理内容を記述したソースファイルです。

### 4.1. コンストラクタ `Ros2UDP()`

オブジェクトが作成される際に、UDP通信の初期設定を行います。

```cpp
Ros2UDP::Ros2UDP(const std::string &f7_address, int f7_port) {
  // UDP通信用のソケットを作成します。
  // AF_INET: IPv4 インターネットプロトコル
  // SOCK_DGRAM: データグラムソケット (UDP)
  // 0: プロトコルは自動選択
  sock = socket(AF_INET, SOCK_DGRAM, 0);

  // 送信先のアドレス情報を設定します。
  f7_addr.sin_family = AF_INET;  // プロトコルファミリをIPv4に設定
  f7_addr.sin_port =
      htons(f7_port);  // ポート番号をネットワークバイトオーダーに変換
  f7_addr.sin_addr.s_addr =
      inet_addr(f7_address.c_str());  // IPアドレス文字列をバイナリ形式に変換
}
```

1.  **`sock = socket(AF_INET, SOCK_DGRAM, 0);`**: OSに対して「ソケットを1つ作ってください」とお願いするシステムコールです。
    -   `AF_INET`: アドレスファミリとしてIPv4を使います、という指定。
    -   `SOCK_DGRAM`: データグラム（パケット単位で送受信し、接続の確立はしない）ソケット、つまりUDPを使います、という指定。
    -   `0`: プロトコルを自動で選択させます（`AF_INET` と `SOCK_DGRAM` の組み合わせなので、自動的にUDPプロトコルが選択されます）。
    -   成功すると、ソケットを識別するための整数値（ファイルディスクリプタ）が返され、`sock` メンバ変数に格納されます。
2.  **`f7_addr.sin_family = AF_INET;`**: 送信先のアドレス情報を格納する `f7_addr` 構造体のプロトコルファミリを、ここでもIPv4に設定します。
3.  **`f7_addr.sin_port = htons(f7_port);`**: ポート番号を設定します。
    -   `htons`（Host to Network Short）関数は、CPUのアーキテクチャによって異なる数値の内部表現（バイトオーダー、エンディアン）を、ネットワーク通信で標準的に使われる「ネットワークバイトオーダー」に変換する重要な役割を持ちます。これを怠ると、異なるアーキテクチャのマシン間で正しく通信できません。
4.  **`f7_addr.sin_addr.s_addr = inet_addr(f7_address.c_str());`**: IPアドレスの文字列（例: `"192.168.0.101"`）を、ネットワークバイトオーダーの32ビット整数値に変換して設定します。
    -   `f7_address.c_str()`: C++の `std::string` を、C言語スタイルの文字列（`const char*`）に変換しています。

### 4.2. `send_packet()` 関数

実際にデータを送信する関数です。

```cpp
ssize_t Ros2UDP::send_packet(uint8_t *packet, size_t size) {
  // sendtoシステムコールを使用して、コンストラクタで設定したアドレスに
  // UDPパケットを送信します。
  return sendto(sock, packet, size, 0, (struct sockaddr *)&f7_addr,
                sizeof(f7_addr));
}
```

-   `return sendto(...)`: `sendto` システムコールを呼び出し、その戻り値をそのままこの関数の戻り値として返します。
    -   `sock`: データを送信するソケットを指定します（コンストラクタで作成したもの）。
    -   `packet`: 送信するデータが格納されているメモリの先頭アドレスです。
    -   `size`: 送信するデータのサイズ（バイト数）です。
    -   `0`: 送信フラグ。通常は0を指定します。
    -   `(struct sockaddr *)&f7_addr`: 送信先のアドレス情報が入った構造体へのポインタを渡します。`sockaddr_in` 型を `sockaddr` 型にキャスト（型変換）しています。
    -   `sizeof(f7_addr)`: 送信先アドレス構造体のサイズを渡します。
-   **戻り値**: 成功した場合は実際に送信されたバイト数が、エラーが発生した場合は `-1` が返されます。

### 4.3. `udp_bind()` と `udp_recv()` （現在未使用）

```cpp
/**
 * @brief ソケットにアドレスをバインドします（現在未使用）。
 */
void Ros2UDP::udp_bind() {
  bind(sock, (const struct sockaddr *)&f7_addr, sizeof(f7_addr));
}

/**
 * @brief UDPパケットを受信する関数の実装（現在未使用）。
 */
ssize_t Ros2UDP::udp_recv(uint8_t *buf, size_t size) {
  // 受信バッファをゼロクリアします。
  memset(buf, 0, size);
  // recvシステムコールを使用してデータを受信します。
  return recv(sock, buf, size, 0);
}
```

-   これらの関数は、UDPパケットを受信するために準備されていますが、現在のプロジェクトでは送信機能しか使われていないため、実際には呼び出されていません。
-   `bind()`: ソケットに特定のポート番号を割り当て、「このポートに来たパケットを自分が受け取ります」とOSに登録する関数です。サーバー側で必要になります。
-   `recv()`: 実際にデータを受信する関数です。データが来るまで処理をブロック（待機）します。
-   `memset(buf, 0, size)`: 受信用のバッファ `buf` を、受信前にゼロでクリアしています。