# `AzimuthControl.msg` 超詳細解説

## 1. ファイル概要

このファイルは、`azimuth_teleop` パッケージ内で使用される**カスタムメッセージ** `AzimuthControl` の定義です。

ROSのメッセージファイル（`.msg`）は、トピックを介してノード間でやり取りされるデータの「構造」を定義するためのシンプルなテキストファイルです。この `AzimuthControl` メッセージは、`azimuth_commander_node` が計算した各スラスターへの具体的な指令を、`f7_interface_node` へと伝達するために使用されます。

`f7_interface_node` は、このメッセージを受け取ると、その内容をSTM32マイコンが解釈できるバイナリ形式（`ControlData` 構造体）に変換してUDPで送信します。

## 2. メッセージ定義

```
# msg/AzimuthControl.msg

# 主機（後方左右のアジマススラスター）
float64 target_rpm_l
float64 target_rpm_r
float64 target_angle_l
float64 target_angle_r

# バウスラスター（前方の左右スラスター）
float64 target_bow_rpm_l
float64 target_bow_rpm_r

# その他
bool led_active
```

## 3. フィールド詳細解説

メッセージは「**型名** **フィールド名**」の形式で一行ずつ定義されます。ここで定義されたフィールドが、C++のコード内では `msg->フィールド名` のようにしてアクセスされます。

--- 

### 主機（アジマススラスター）

`float64 target_rpm_l`
-   **型**: `float64` (64ビット浮動小数点数、C++では `double`)
-   **説明**: **左側**の主機（アジマススラスター）の目標回転数。
-   **単位**: RPM (Revolutions Per Minute)

`float64 target_rpm_r`
-   **型**: `float64`
-   **説明**: **右側**の主機（アジマススラスター）の目標回転数。
-   **単位**: RPM

`float64 target_angle_l`
-   **型**: `float64`
-   **説明**: **左側**の主機の目標角度。船の前後方向（船首方向）を0度とし、右回りを正とすることが一般的です。
-   **単位**: 度 (degree)

`float64 target_angle_r`
-   **型**: `float64`
-   **説明**: **右側**の主機の目標角度。
-   **単位**: 度 (degree)

--- 

### バウスラスター

`float64 target_bow_rpm_l`
-   **型**: `float64`
-   **説明**: **左側**のバウスラスターの目標回転数。バウスラスターは横方向にしか推力を出せません。
-   **単位**: RPM
-   **向き**: 一般的に、正の値が船首を右に押す推力（船首が右に回頭）、負の値が船首を左に押す推力に対応します。

`float64 target_bow_rpm_r`
-   **型**: `float64`
-   **説明**: **右側**のバウスラスターの目標回転数。
-   **単位**: RPM
-   **向き**: `target_bow_rpm_l` と同じ規約に従います。

--- 

### その他

`bool led_active`
-   **型**: `bool` (ブール値、C++では `bool`)
-   **説明**: LEDの点灯状態などを制御するための汎用的なフラグです。`true` で点灯、`false` で消灯といった使い方を想定していますが、現在の実装では使用されていない可能性があります。