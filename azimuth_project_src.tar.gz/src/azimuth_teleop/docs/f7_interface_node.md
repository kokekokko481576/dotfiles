# `f7_interface_node.cpp` 超詳細解説

## 1. ファイル概要

このファイルは、ROS 2の世界と、船のハードウェアを直接制御するSTM32 F7マイコンとを繋ぐ「ブリッジ」の役割を担うROS 2ノードです。

上位のノード（`azimuth_commander_node`）から送られてくる `/azimuth_command` トピック（`azimuth_teleop/msg/AzimuthControl`型）を購読します。このメッセージには、各スラスターの目標RPMや目標角度といった、抽象化された指令が含まれています。

`f7_interface_node` は、このROSメッセージを、STM32マイコンが直接解釈できる固定長のバイナリデータ構造体 (`ControlData`) に変換し、指定されたIPアドレスとポート番号にUDPパケットとして送信します。これにより、ROS 2が動作するPCと、リアルタイム性が求められるハードウェア制御マイコンとを、ネットワークを介して綺麗に分離することができます。

## 2. インクルード

このノードが必要とするヘッダーファイルです。

```cpp
#include <cerrno>
#include <cstring>

#include "azimuth_teleop/msg/azimuth_control.hpp"
#include "azimuth_teleop/ros2_udp.hpp"
#include "rclcpp/rclcpp.hpp"
```

-   `#include <cerrno>`: C言語の標準ライブラリで、システムコールが失敗した際にエラーの理由を示すグローバル変数 `errno` を使うためにインクルードします。
-   `#include <cstring>`: C言語の標準ライブラリで、`strerror` 関数を使うためにインクルードします。`strerror` は `errno` の数値を、人間が読めるエラーメッセージの文字列（例：「Connection refused」）に変換します。
-   `#include "azimuth_teleop/msg/azimuth_control.hpp"`: 購読するスラスター指令メッセージ `AzimuthControl` の型定義です。
-   `#include "azimuth_teleop/ros2_udp.hpp"`: UDP通信を簡単に行うために自作したラッパークラス `Ros2UDP` のヘッダーです。
-   `#include "rclcpp/rclcpp.hpp"`: ROS 2のC++クライアントライブラリのコア機能を提供します。

## 3. `ControlData` 構造体

STM32マイコンにUDPで送信するための、生（バイナリ）のデータ形式を定義した構造体です。

```cpp
/**
 * @struct ControlData
 * @brief STM32マイコンに送信するためのデータ構造体。
 * @warning この構造体のメンバ変数の【順番、型、サイズ】は、マイコン側の
 * ファームウェアで定義されている受信用の構造体と完全に一致させる必要があります。
 * どちらかに変更を加えた場合は、もう一方も必ず同期させてください。
 * 一致していない場合、データが破損したり、予期せぬ動作を引き起こす原因となります。
 */
struct ControlData {
  float target_rpm_l;
  float target_rpm_r;
  float target_angle_l;
  float target_angle_r;
  float target_bow_rpm_l;
  float target_bow_rpm_r;
};
```

-   **最重要警告**: この構造体は、ROS PCとSTM32マイコンの間の「通信プロトコル（通信規約）」そのものです。メンバ変数の **順番、型、サイズ** のすべてが、マイコン側の受信プログラムで定義されている構造体と **完全に一致** している必要があります。例えば、PC側で `float` を `double` に変更したり、メンバの順番を入れ替えたりした場合、マイコン側も全く同じように変更しないと、データが正しく解釈されず（専門用語で「エンディアンの違い」や「パディング」の問題も絡むことがあります）、デバッグの非常に困難なバグの原因となります。
-   `float target_...`: 各スラスターへの指令値を `float` 型（32ビット浮動小数点数）で定義しています。

## 4. `F7InterfaceNode` クラス

ROSメッセージを購読し、UDPパケットとして送信する機能を持つクラスです。`rclcpp::Node` をパブリックに継承しています。

```cpp
class F7InterfaceNode : public rclcpp::Node {
// ... クラス定義 ...
};
```

### 4.1. コンストラクタ `F7InterfaceNode()`

ノードが初期化されるときに一度だけ呼ばれるコンストラクタです。

#### 4.1.1. ノード名の初期化と送信先情報の設定

```cpp
  F7InterfaceNode() : Node("f7_interface_node") {
    // 注意: 現状、送信先のIPアドレスとポートはハードコードされています。
    // 将来的に、ROSパラメータから読み込むように変更することが望ましいです。
    const std::string STM32_IP = "192.168.0.101";
    const int STM32_PORT = 12345;
```

-   `Node("f7_interface_node")`: 親クラスのコンストラクタを呼び出し、ノード名を `"f7_interface_node"` に設定します。
-   `const std::string STM32_IP = "192.168.0.101";`: 送信先であるSTM32マイコンのIPアドレスを文字列として定義します。現状はソースコード内に直接記述（ハードコード）されていますが、将来的にはROSパラメータとして外部から設定できるようにすると、より柔軟性が高まります。
-   `const int STM32_PORT = 12345;`: 送信先のポート番号を整数として定義します。

#### 4.1.2. UDP送信機の作成とサブスクライバーの作成

```cpp
    // UDP送信機を作成
    udp_sender_ = std::make_unique<Ros2UDP>(STM32_IP, STM32_PORT);

    // サブスクライバーを作成
    subscription_ =
        this->create_subscription<azimuth_teleop::msg::AzimuthControl>(
            "azimuth_command", 10,
            std::bind(&F7InterfaceNode::command_callback, this,
                      std::placeholders::_1));

    RCLCPP_INFO(this->get_logger(),
                "F7 Interface Node has been started. Sending to %s:%d",
                STM32_IP.c_str(), STM32_PORT);
  }
```

-   `udp_sender_ = std::make_unique<Ros2UDP>(STM32_IP, STM32_PORT);`: `Ros2UDP` クラスのインスタンスを作成し、メンバ変数 `udp_sender_` に格納します。`std::make_unique` はメモリを安全に管理するためのスマートポインタを作成するC++の機能です。コンストラクタにIPアドレスとポート番号を渡すことで、UDP通信の準備が整います。
-   `subscription_ = this->create_subscription<...>(...)`: `/azimuth_command` トピックを購読するためのサブスクライバーを作成し、メッセージが届いたら `command_callback` 関数を呼び出すように設定します。
-   `RCLCPP_INFO(...)`: コンストラクタの最後に、ノードが起動し、どのIPアドレスとポートにデータを送信しようとしているのかを情報ログとしてコンソールに出力します。

### 4.2. `command_callback()` 関数

`/azimuth_command` トピックから `AzimuthControl` メッセージを受信するたびに実行されるコールバック関数です。

#### 4.2.1. データのコピー

```cpp
  void command_callback(
      const azimuth_teleop::msg::AzimuthControl::SharedPtr msg) {
    // 1. ROSメッセージから送信用データ構造体へ内容をコピー
    ControlData packet_to_send;
    packet_to_send.target_rpm_l = msg->target_rpm_l;
    packet_to_send.target_rpm_r = msg->target_rpm_r;
    packet_to_send.target_angle_l = msg->target_angle_l;
    packet_to_send.target_angle_r = msg->target_angle_r;
    packet_to_send.target_bow_rpm_l = msg->target_bow_rpm_l;
    packet_to_send.target_bow_rpm_r = msg->target_bow_rpm_r;
```

-   `const azimuth_teleop::msg::AzimuthControl::SharedPtr msg`: 受信した `AzimuthControl` メッセージが、スマートポインタ `SharedPtr` として `msg` 引数に渡されます。
-   `ControlData packet_to_send;`: UDPで送信するための `ControlData` 型のローカル変数 `packet_to_send` を作成します。
-   `packet_to_send.target_rpm_l = msg->target_rpm_l;`: 受信したROSメッセージ (`msg`) の各フィールドの値を、送信用の構造体 (`packet_to_send`) の対応するフィールドに一つずつコピーしていきます。

#### 4.2.2. UDP送信とエラーハンドリング

```cpp
    // 2. 構造体をバイト列としてUDP送信
    ssize_t sent_bytes = udp_sender_->send_packet(
        reinterpret_cast<uint8_t*>(&packet_to_send), sizeof(packet_to_send));
    
    // 3. エラーハンドリング
    if (sent_bytes < 0) {
      RCLCPP_ERROR(this->get_logger(), "Failed to send UDP packet: %s",
                   strerror(errno));
    }
  }
```

-   `udp_sender_->send_packet(...)`: `Ros2UDP` クラスの `send_packet` 関数を呼び出して、実際にデータを送信します。
    -   **第一引数**: `reinterpret_cast<uint8_t*>(&packet_to_send)`
        -   `&packet_to_send`: `ControlData` 構造体 `packet_to_send` のメモリアドレスを取得します。
        -   `reinterpret_cast<uint8_t*>()`: C++の強力な型変換機能です。ここでは、「`ControlData` という構造体の先頭アドレス」を、単なる「符号なし8ビット整数の配列（つまり、ただのバイト列）の先頭アドレス」として解釈し直しています。`send_packet` 関数はバイト列を引数に取るため、この変換が必要です。これにより、構造体のメモリ上の内容がそのままの形で、一つの塊としてUDPパケットの中身になります。
    -   **第二引数**: `sizeof(packet_to_send)`
        -   `sizeof` 演算子を使って、`ControlData` 構造体全体のサイズ（バイト数）を取得し、送信するデータ長として渡します。
-   `ssize_t sent_bytes = ...`: `send_packet` 関数の戻り値（送信に成功したバイト数、またはエラーを示す-1）を `sent_bytes` 変数に格納します。
-   `if (sent_bytes < 0)`: 送信が失敗したかどうかをチェックします。
-   `RCLCPP_ERROR(..., strerror(errno))`: もし送信が失敗した場合、`errno` に格納されたシステムエラーコードを `strerror` で文字列に変換し、「なぜ失敗したのか」（例：「Network is unreachable」）をエラーログとして出力します。

### 4.3. メンバ変数

クラス内で使用するサブスクライバーとUDP送信機のオブジェクトです。

```cpp
  // === メンバ変数 ===
  rclcpp::Subscription<azimuth_teleop::msg::AzimuthControl>::SharedPtr
      subscription_;
  std::unique_ptr<Ros2UDP> udp_sender_;
```

-   `subscription_`: `/azimuth_command` を購読するためのサブスクライバーオブジェクトを保持します。
-   `udp_sender_`: `Ros2UDP` オブジェクトを管理するためのスマートポインタ `std::unique_ptr` です。`F7InterfaceNode` オブジェクトが破棄される際に、自動的に `Ros2UDP` オブジェクトも破棄され、ソケットが閉じられるなど、メモリ管理が安全に行われます。

## 5. `main` 関数

このプログラムのエントリーポイントです。`F7InterfaceNode` のインスタンスを作成し、ROS 2のループを開始します。

```cpp
int main(int argc, char* argv[]) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<F7InterfaceNode>());
  rclcpp::shutdown();
  return 0;
}
```