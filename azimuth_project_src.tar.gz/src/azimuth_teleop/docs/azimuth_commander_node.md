# `azimuth_commander_node.cpp` 超詳細解説

## 1. ファイル概要

このファイルは、船全体の抽象的な速度指令（例：「前方に秒速0.5m、毎秒10度で右回転」）を、個々のスラスターが実行すべき具体的な指令（例：「右スラスターは角度30度で1500RPM、バウスラスターは-500RPM」）に変換するためのROS 2ノードです。

この計算は「推力配分 (Thrust Allocation)」と呼ばれ、船の運動制御における心臓部の一つです。

このノードは `/cmd_vel` トピック（`geometry_msgs/msg/Twist`型）を購読し、船全体の並進速度・回転速度指令を受け取ります。受け取った指令と、ROSパラメータから読み込んだ船の物理的な設定値（スラスター間の距離など）に基づいて、各アジマススラスターとバウスラスターが達成すべきRPM（回転数）と角度を計算します。

計算結果は、カスタムメッセージ `azimuth_teleop/msg/AzimuthControl` 型で `/azimuth_command` トピックとしてパブリッシュされます。

## 2. インクルード

このノードが必要とするヘッダーファイルです。

```cpp
#include <cmath>

#include "azimuth_teleop/msg/azimuth_control.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "rclcpp/rclcpp.hpp"
```

-   `#include <cmath>`: `std::atan2`（逆正接）や `std::hypot`（斜辺の長さ）など、ベクトル計算に必要な数学関数を使用するためにインクルードします。
-   `#include "azimuth_teleop/msg/azimuth_control.hpp"`: このノードが計算結果をパブリッシュするために使用するカスタムメッセージの型定義です。このメッセージに、各スラスターのRPMや角度の指令値が格納されます。
-   `#include "geometry_msgs/msg/twist.hpp"`: `twist_mux` から船全体の速度指令を受け取るための `Twist` メッセージ型を定義しています。
-   `#include "rclcpp/rclcpp.hpp"`: ROS 2のC++クライアントライブラリのコア機能（ノード、Pub/Subなど）を提供します。

## 3. `AzimuthCommanderNode` クラス

速度指令をスラスター指令に変換する計算ロジックを実装したクラスです。`rclcpp::Node` をパブリックに継承することで、ROS 2のノードとしての機能を使えるようになります。

```cpp
class AzimuthCommanderNode : public rclcpp::Node {
// ... クラス定義 ...
};
```

### 3.1. コンストラクタ `AzimuthCommanderNode()`

ノードが初期化されるときに一度だけ呼ばれるコンストラクタです。ここで、計算に必要なパラメータを宣言し、通信のためのPub/Subを設定します。

#### 3.1.1. ノード名の初期化

```cpp
  AzimuthCommanderNode() : Node("azimuth_commander_node") {
```

-   `Node("azimuth_commander_node")`: 親クラスである `rclcpp::Node` のコンストラクタを呼び出し、ROSネットワーク上でのノード名を `"azimuth_commander_node"` に設定します。

#### 3.1.2. ROSパラメータの宣言

```cpp
    // === パラメータ宣言 ===
    // 船の物理的なジオメトリや変換係数を設定します。

    this->declare_parameter<double>(
        "thruster_distance",
        0.5);  // 船の中心から左右の主機スラスターまでの距離 [m]
    this->declare_parameter<double>(
        "vel_to_rpm_ratio",
        1000.0);  // 速度 [m/s] をRPMに変換するための係数
    this->declare_parameter<double>(
        "bow_thruster_distance",
        1.0);  // 船の中心からバウスラスターまでの距離 [m]
```

-   `this->declare_parameter<double>("thruster_distance", 0.5);`: 船の中心から左右の主推進器（アジマススラスター）までの距離（の半分）を `double` 型のパラメータとして宣言します。デフォルト値は `0.5` [m] です。この値は、回転運動を計算する際のモーメントアームとして極めて重要です。
-   `this->declare_parameter<double>("vel_to_rpm_ratio", 1000.0);`: 速度 [m/s] をスラスターの回転数 [RPM] に変換するための係数を宣言します。これは、スラスターの性能やプロペラの特性によって決まる値です。
-   `this->declare_parameter<double>("bow_thruster_distance", 1.0);`: 船の中心からバウスラスターまでの距離を宣言します。これも回転運動の計算に使われる重要な物理パラメータです。

#### 3.1.3. サブスクライバーとパブリッシャーの作成

```cpp
    // === サブスクライバーとパブリッシャーの作成 ===
    cmd_vel_sub_ = this->create_subscription<geometry_msgs::msg::Twist>(
        "cmd_vel", 10,
        std::bind(&AzimuthCommanderNode::cmd_vel_callback, this,
                  std::placeholders::_1));
    azimuth_cmd_pub_ =
        this->create_publisher<azimuth_teleop::msg::AzimuthControl>(
            "azimuth_command", 10);
    RCLCPP_INFO(this->get_logger(), "Azimuth Commander Node has been started.");
  }
```

-   `cmd_vel_sub_ = this->create_subscription<...>(...)`: `/cmd_vel` トピックを購読するためのサブスクライバーを作成します。`twist_mux` が集約した最終的な船の速度指令がこのトピックに流れてくるので、それを `cmd_vel_callback` 関数で受け取ります。
-   `azimuth_cmd_pub_ = this->create_publisher<...>(...)`: 計算結果である各スラスターへの具体的な指令を、`/azimuth_command` トピックに `AzimuthControl` メッセージ型でパブリッシュするためのパブリッシャーを作成します。
-   `RCLCPP_INFO(...)`: コンストラクタの最後に、ノードが正常に起動したことを示す情報ログをコンソールに出力します。

### 3.2. `cmd_vel_callback()` 関数

`/cmd_vel` トピックから `Twist` メッセージを受信するたびに実行されるコールバック関数です。この中で、指令値の変換計算のすべてが行われます。

#### 3.2.1. パラメータの取得と指令値の格納

```cpp
  void cmd_vel_callback(const geometry_msgs::msg::Twist::SharedPtr msg) {
    // --- パラメータを取得 ---
    const double d = this->get_parameter("thruster_distance").as_double();
    const double vel_to_rpm =
        this->get_parameter("vel_to_rpm_ratio").as_double();
    const double bow_d =
        this->get_parameter("bow_thruster_distance").as_double();

    // --- 指令値を変数に格納 ---
    const double linear_x = msg->linear.x;    // 前後方向の並進速度
    const double linear_y = msg->linear.y;    // 横方向の並進速度
    const double angular_z = msg->angular.z;  // Z軸周りの回転角速度

    auto cmd = azimuth_teleop::msg::AzimuthControl();
  }
```

-   `const geometry_msgs::msg::Twist::SharedPtr msg`: 受信した `Twist` メッセージが、スマートポインタ `SharedPtr` として `msg` 引数に渡されます。
-   `this->get_parameter(...).as_double()`: 計算の前に、最新のROSパラメータを取得します。これにより、実行中にパラメータを変更しても動的に計算に反映されます。
-   `const double linear_x = msg->linear.x;`: 受信した `Twist` メッセージの中身を、分かりやすい名前のローカル変数にコピーします。`linear.x` は船の前後方向の速度 [m/s]、`linear.y` は横方向の速度 [m/s]、`angular.z` は船の中心周りの回転角速度 [rad/s] を表します。
-   `auto cmd = azimuth_teleop::msg::AzimuthControl();`: パブリッシュするための `AzimuthControl` 型のメッセージオブジェクトを `cmd` という名前で作成します。

#### 3.2.2. 主機スラスターの計算

船全体の並進運動と回転運動を同時に実現するために、左右の主機（アジマススラスター）がそれぞれ生成すべき推力ベクトル（X方向とY方向の速度成分）を計算します。

```cpp
    // === 主機スラスターの計算 ===
    double thrust_lx = linear_x - angular_z * d; // 左主機のX方向推力
    double thrust_ly = linear_y;                 // 左主機のY方向推力
    double thrust_rx = linear_x + angular_z * d; // 右主機のX方向推力
    double thrust_ry = linear_y;                 // 右主機のY方向推力
```

-   **計算の原理**: この計算は、剛体の運動学に基づいています。船の中心から距離 `d` の位置にある点の速度は、「船全体の並進速度」と「回転によって生じる接線速度」のベクトル和になります。
-   `angular_z * d`: これが回転によって生じる接線速度の大きさです。船を右回転（`angular_z` が正）させると、船の中心から見て左側にある点は後方（-X方向）に、右側にある点は前方（+X方向）に動きます。
-   `thrust_lx = linear_x - angular_z * d;`: 左主機が担当すべきX方向速度は、船全体の前進速度 `linear_x` から、回転による後退分の速度 `angular_z * d` を引いたものになります。
-   `thrust_rx = linear_x + angular_z * d;`: 同様に、右主機が担当すべきX方向速度は、船全体の前進速度 `linear_x` に、回転による前進分の速度 `angular_z * d` を足したものになります。
-   `thrust_ly = linear_y;`: Y方向（横方向）の速度は、このモデルでは単純に左右のスラスターで同じ値を分担するものとしています。

次に、計算したXYの速度ベクトルを、スラスターが実際に指令できる形式である「角度」と「強さ（RPM）」の極座標形式に変換します。

```cpp
    // 速度ベクトルを極座標（角度と大きさ）に変換し、指令値を生成します。
    cmd.target_angle_l =
        std::atan2(thrust_ly, thrust_lx) * 180.0 / M_PI;  // 左主機の目標角度 [deg]
    cmd.target_rpm_l =
        std::hypot(thrust_lx, thrust_ly) * vel_to_rpm;  // 左主機の目標RPM

    cmd.target_angle_r =
        std::atan2(thrust_ry, thrust_rx) * 180.0 / M_PI;  // 右主機の目標角度 [deg]
    cmd.target_rpm_r =
        std::hypot(thrust_rx, thrust_ry) * vel_to_rpm;  // 右主機の目標RPM
```

-   `std::atan2(y, x)`: XY座標から角度を計算する標準ライブラリ関数です。`atan(y/x)` と違い、4象限すべてで正しい角度を返します。結果はラジアン単位です。
-   `* 180.0 / M_PI`: `atan2` の結果（ラジアン）を、人間が分かりやすい度（degree）単位に変換しています。`M_PI` は `<cmath>` で定義されている円周率πです。
-   `std::hypot(x, y)`: XYベクトルの大きさ（ユークリッド距離 `sqrt(x*x + y*y)`) を計算する標準ライブラリ関数です。これがスラスターが出すべき推力の強さ（速度）になります。
-   `* vel_to_rpm`: 計算された速度を、パラメータで設定した係数を使ってRPMに変換します。

#### 3.2.3. バウスラスターの計算

バウスラスターは船首にあり、横方向の推力のみを生成します。主に、船首を左右に振る（ヨー回転を補助する）役割と、船全体の横移動（スウェイ）を補助する役割を担います。

```cpp
    // === バウスラスターの計算 ===
    double total_bow_thrust_y = linear_y + angular_z * bow_d;

    double final_bow_rpm = total_bow_thrust_y * vel_to_rpm;

    cmd.target_bow_rpm_l = final_bow_rpm;
    cmd.target_bow_rpm_r = final_bow_rpm;
```

-   `total_bow_thrust_y = linear_y + angular_z * bow_d;`: バウスラスターが担当すべき合計の横方向推力を計算します。これは、「船全体の横移動 `linear_y`」と、「船体の回転によって船首部分（距離 `bow_d`）で発生する接線速度 `angular_z * bow_d`」の和になります。
-   `final_bow_rpm = total_bow_thrust_y * vel_to_rpm;`: 計算した合計推力を、係数を使ってRPMに変換します。正の値は船首を右に、負の値は左に押す力に対応します。
-   `cmd.target_bow_rpm_l = final_bow_rpm; cmd.target_bow_rpm_r = final_bow_rpm;`: このモデルでは、2つのバウスラスターは常に同じ指令値で動作するものとして、同じ値を設定しています。

#### 3.2.4. 指令のパブリッシュ

```cpp
    // --- 指令をパブリッシュ ---
    azimuth_cmd_pub_->publish(cmd);
  }
```

-   `azimuth_cmd_pub_->publish(cmd);`: 計算したすべての値を格納した `AzimuthControl` メッセージ `cmd` を、`/azimuth_command` トピックにパブリッシュします。これにより、`f7_interface_node` が指令を受け取ることができます。

### 3.3. メンバ変数

クラス内で状態を保持したり、ROSの機能（Pub/Sub）にアクセスしたりするための変数です。

```cpp
  // === メンバ変数 ===
  rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_sub_;
  rclcpp::Publisher<azimuth_teleop::msg::AzimuthControl>::SharedPtr
      azimuth_cmd_pub_;
```

-   `cmd_vel_sub_`: `/cmd_vel` を購読するためのサブスクライバーオブジェクトを保持します。
-   `azimuth_cmd_pub_`: `/azimuth_command` にパブリッシュするためのパブリッシャーオブジェクトを保持します。

## 4. `main` 関数

このプログラムのエントリーポイント（開始地点）です。

```cpp
int main(int argc, char *argv[]) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<AzimuthCommanderNode>());
  rclcpp::shutdown();
  return 0;
}
```

-   `rclcpp::init(argc, argv)`: ROS 2を初期化します。
-   `rclcpp::spin(...)`: `AzimuthCommanderNode` のインスタンスを作成し、コールバック関数が呼ばれるのを待ち続けるROS 2のイベントループを開始します。
-   `rclcpp::shutdown()`: `spin` が終了した後に、ROS 2のシステムをクリーンアップして終了します。