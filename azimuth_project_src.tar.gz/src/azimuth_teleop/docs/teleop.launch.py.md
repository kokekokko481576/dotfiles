# `teleop.launch.py` 超詳細解説

## 1. ファイル概要

このファイルは、`azimuth_teleop` パッケージのメインとなるROS 2の起動ファイル（Launch File）です。`ros2 launch azimuth_teleop teleop.launch.py` コマンドで実行されます。

このファイルの主な役割は、手動操縦に必要な5つのノード（`joy_node`, `manual_teleop_node`, `twist_mux`, `azimuth_commander_node`, `f7_interface_node`）を、それぞれ適切な設定（パラメータ）で一度に起動することです。

特に、PCに接続されたジョイスティックコントローラーを自動的に検出し、その種類に応じた設定ファイルを読み込むという、インテリジェントな機能を持っています。

## 2. インポート

起動ファイルの冒頭で、このスクリプトが必要とするPythonモジュールをインポートします。

```python
import os
import glob
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node
```

-   `import os`: オペレーティングシステムと対話するための機能を提供します。ここでは主に、`os.path.join` を使って、OS（Linux, Windows, macOS）の違いを吸収し、正しくファイルパスを結合するために使用されます。
-   `import glob`: 指定したパターンに一致するファイルパスのリストを取得するために使用します。このファイルでは直接使われていませんが、以前のバージョンで `/dev/input/js*` を探すために使われていました。
-   `from ament_index_python.packages import get_package_share_directory`: ROS 2のパッケージがインストールされた場所にある `share` ディレクトリの絶対パスを取得するための関数です。設定ファイル（YAML）などを読み込む際に、環境に依存しないパスを指定するために必須です。
-   `from launch import LaunchDescription`: 起動するノードのリストを保持する、Launchシステムの最も基本的なコンテナ（入れ物）です。
-   `from launch_ros.actions import Node`: ROS 2のノードを起動するための「アクション」を定義するクラスです。

---

## 3. `evdev` ライブラリのインポートとチェック

この起動ファイルの核となる、`evdev` ライブラリをインポートします。

```python
# evdevライブラリをインポート
try:
    import evdev
except ImportError:
    print("==================================================================================")
    print("evdevライブラリが見つかりません！ 'pip install evdev' を実行してください。")
    print("==================================================================================")
    exit()
```

-   `try...except ImportError`: このブロックは、`evdev` ライブラリのインポートを試み、もし失敗した場合（＝ライブラリがインストールされていない場合）にプログラムがクラッシュするのを防ぎます。
-   `import evdev`: Linuxのイベントデバイス（`/dev/input/event*`）にPythonから直接アクセスするためのライブラリです。これにより、接続されているデバイスの名前、ベンダーID、プロダクトIDといった詳細な情報を取得できます。
-   `except ImportError:`: `import evdev` が失敗した場合に、このブロック内のコードが実行されます。
-   `print(...)`: ユーザーに対して、ライブラリが不足していることと、それをインストールするためのコマンド (`pip install evdev`) を分かりやすく表示します。
-   `exit()`: 不足しているライブラリがあるとこの先の処理は続けられないため、スクリプトをここで終了させます。

---

## 4. `generate_launch_description()` 関数

ROS 2のLaunchシステムが、起動ファイルを実行する際に呼び出すメインの関数です。この関数が返した `LaunchDescription` オブジェクトの内容に基づいて、ノード群が起動されます。

```python
def generate_launch_description():
    # ... (この関数の中ででで、すべての処理が行われる) ...
```

### 4.1. パッケージ共有ディレクトリのパス取得

```python
    pkg_share = get_package_share_directory('azimuth_teleop')
```

-   `get_package_share_directory('azimuth_teleop')`: `azimuth_teleop` パッケージの `share` ディレクトリへの絶対パスを取得します。例えば、`/home/kokko/ros2_workspaces/azimuth_project/install/azimuth_teleop/share` のようなパスが `pkg_share` 変数に格納されます。これにより、この後の設定ファイルのパスを正確に指定できます。

### 4.2. コントローラー自動検出ロジック

この部分が、接続されたコントローラーを識別し、対応する設定ファイルを決定する、この起動ファイルの最も重要なロジックです。

#### 4.2.1. 変数の初期化

```python
    # --- コントローラー自動検出ロジック ---
    default_joy_config_name = 'hori.yaml'
    joy_device_name = None # joy_nodeに渡すデバイス名
```

-   `default_joy_config_name = 'hori.yaml'`: もし、対応するコントローラーが一つも見つからなかった場合に、デフォルトで読み込む設定ファイル名を `hori.yaml` に設定しておきます。
-   `joy_device_name = None`: `joy_node` に渡すためのデバイス名を格納する変数です。`None`（何も入っていない状態）で初期化しておき、コントローラーが見つかった場合に、その名前を格納します。

#### 4.2.2. デバイスのスキャンと判定

```python
    try:
        devices = [evdev.InputDevice(path) for path in evdev.list_devices()]
        for device in devices:
            device_name_lower = device.name.lower()
```

-   `try...except Exception`: `evdev` でデバイスをスキャンする際に、権限の問題などでエラーが発生する可能性があるため、`try` ブロックで囲み、予期せぬクラッシュを防ぎます。
-   `evdev.list_devices()`: `/dev/input/event*` のリストを返します。
-   `devices = [evdev.InputDevice(path) for path in ... ]`: リスト内包表記を使い、見つかった全てのイベントデバイスパスに対して `evdev.InputDevice` オブジェクトを作成し、`devices` リストに格納します。これにより、各デバイスの詳細情報にアクセスできるようになります。
-   `for device in devices:`: `devices` リストの中身を一つずつ取り出し、`device` 変数に入れてループ処理を行います。
-   `device_name_lower = device.name.lower()`: デバイスの名前（例: `'Xbox Wireless Controller'`）を取得し、後の文字列比較を簡単にするために、すべて小文字に変換しています。

#### 4.2.3. 条件分岐によるコントローラーの特定

```python
            # HORI
            if 'hori' in device_name_lower:
                print(f"INFO: HORIコントローラーを発見: {device.name}")
                default_joy_config_name = 'hori.yaml'
                joy_device_name = device.name
                break
```

-   `if 'hori' in device_name_lower:`: デバイス名の小文字版に `'hori'` という文字列が含まれているかをチェックします。
-   **もし含まれていれば (True の場合)**:
    -   `print(...)`: ユーザーにどのコントローラーが見つかったかを知らせる `INFO` メッセージを表示します。
    -   `default_joy_config_name = 'hori.yaml'`: 読み込むべき設定ファイル名を `hori.yaml` に設定します。
    -   `joy_device_name = device.name`: `joy_node` に渡すデバイス名として、元のデバイス名（大文字小文字を保持したもの）を格納します。
    -   `break`: 目的のコントローラーが見つかったので、これ以上他のデバイスをチェックする必要はないため、`for` ループを中断して抜け出します。

```python
            # 8BitDo
            elif '8bitdo' in device_name_lower:
                print(f"INFO: 8BitDoコントローラーを発見: {device.name}")
                default_joy_config_name = '8bitdo.yaml'
                joy_device_name = device.name
                break
```

-   `elif '8bitdo' in device_name_lower:`: 最初の `if` が False だった場合に、次にデバイス名に `'8bitdo'` が含まれているかをチェックします。処理内容は HORI の場合と同様です。

```python
            # BIGBIG WON (Xbox)
            elif device.info.vendor == 0x045e and device.info.product == 0x02e0:
                print(f"INFO: BIGBIG WON (Xbox互換) コントローラーを発見: {device.name}")
                default_joy_config_name = 'bigbig_won.yaml'
                joy_device_name = device.name
                break
```

-   `elif device.info.vendor == 0x045e and device.info.product == 0x02e0:`: 上記の `if`, `elif` が両方 False だった場合に、この条件をチェックします。
    -   `device.info.vendor == 0x045e`: デバイスのベンダーIDが `0x045e` (Microsoft社のID) であるかを確認します。
    -   `device.info.product == 0x02e0`: デバイスのプロダクトIDが `0x02e0` (Xbox One S ControllerのID) であるかを確認します。
    -   `and`: 両方の条件が同時に True である場合にのみ、ブロック内のコードが実行されます。デバイス名ではなく、ハードウェア固有のIDで判定するため、より確実な識が可能です。
-   処理内容は上記と同様です。

#### 4.2.4. 例外処理とフォールバック

```python
    except Exception as e:
        print(f"WARN: evdevによるデバイス検出に失敗: {e}")

    if not joy_device_name:
        print("WARN: 知ってるコントローラーは見つからず。joy_nodeのデフォルトに任せます。")
```

-   `except Exception as e:`: `try` ブロック内で何か予期せぬエラーが発生した場合に、そのエラー内容 `e` をユーザーに警告 (`WARN`) として表示します。これにより、例えばデバイスへのアクセス権限がない場合などに、何が起きているかを知る手がかりになります。
-   `if not joy_device_name:`: `for` ループが最後まで実行されても、`joy_device_name` が `None` のままである（＝既知のコントローラーが一つも見つからなかった）場合に、この `if` ブロックが実行されます。
-   `print("WARN: ...")`: ユーザーに、自動検出が失敗し、`joy_node` のデフォルトの挙動に任せることを警告として伝えます。

### 4.3. 設定ファイルのフルパス確定

```python
    # --- 設定ファイルのパスを確定 ---
    joy_config_path = os.path.join(pkg_share, 'config', default_joy_config_name)
    twist_mux_params_path = os.path.join(pkg_share, 'config', 'twist_mux.yaml')
    teleop_params_path = os.path.join(pkg_share, 'config', 'teleop_params.yaml')
```

-   `os.path.join(...)`: 4.1で取得した `pkg_share` のパスと、`config` ディレクトリ名、そしてファイル名を結合して、各設定ファイルの絶対パスを生成します。
-   `joy_config_path`: 自動検出ロジックで決定されたコントローラー用のYAMLファイル（`hori.yaml` など）へのパスが格納されます。

### 4.4. `joy_node` のパラメータ設定

```python
    # --- joy_node のパラメータ ---
    joy_params = [joy_config_path]
    if joy_device_name:
        joy_params.append({'dev_name': joy_device_name})
    # joy_device_name が見つからない場合は、joy_nodeのデフォルト（/dev/input/js0など）に任せる
```

-   `joy_params = [joy_config_path]`: `joy_node` に渡すパラメータのリストを初期化します。最初に、選択されたコントローラーのYAMLファイルパスを入れています。
-   `if joy_device_name:`: 自動検出でコントローラーが見つかっていた場合 (True) に、このブロックが実行されます。
-   `joy_params.append(...)`: パラメータリストに `{'dev_name': joy_device_name}` という辞書を追加します。`joy_node` はこの `dev_name` パラメータを受け取ると、デバイスパス (`/dev/input/js*`) ではなく、デバイス名でジョイスティックを探しに行きます。これにより、複数のジョイスティックが接続されていても、意図したものを正確に使うことができます。

### 4.5. `LaunchDescription` の作成と返却

最終的に起動するすべてのノードの定義をリストとして格納し、`LaunchDescription` オブジェクトとして返します。

```python
    # --- ノード構成 ---
    return LaunchDescription([
        # ... (各Nodeの定義) ...
    ])
```

#### 4.5.1. `joy_node`

```python
        # 1. joy_node
        Node(
            package='joy',
            executable='joy_node',
            name='joy_node',
            parameters=joy_params
        ),
```

-   `package='joy'`: `ros-humble-joy` パッケージに含まれる `joy_node` を使います。
-   `executable='joy_node'`: 起動する実行ファイル名です。
-   `name='joy_node'`: ROSネットワーク上でのノード名です。
-   `parameters=joy_params`: 4.4で動的に作成したパラメータリストをこのノードに渡します。

#### 4.5.2. `manual_teleop_node`

```python
        # 2. manual_teleop_node
        Node(
            package='azimuth_teleop',
            executable='manual_teleop_node',
            name='manual_teleop_node',
            output='screen',
            parameters=[joy_config_path, teleop_params_path]
        ),
```

-   `package='azimuth_teleop'`: このプロジェクトで自作したノードです。
-   `output='screen'`: このノードのログメッセージ（`RCLCPP_INFO`など）を、コンソール画面に直接表示させるための設定です。
-   `parameters=[...]`: このノードには2つの設定ファイルを渡しています。
    -   `joy_config_path`: どのボタンがどの操作に対応するかのマッピング情報。
    -   `teleop_params_path`: 船の最大速度など、コントローラーの種類に依存しない共通パラメータ。

#### 4.5.3. `twist_mux`

```python
        # 3. twist_mux
        Node(
            package='twist_mux',
            executable='twist_mux',
            name='twist_mux',
            parameters=[twist_mux_params_path],
            remappings=[('/cmd_vel_out', '/cmd_vel')]
        ),
```

-   `package='twist_mux'`: `ros-humble-twist-mux` パッケージのノードです。
-   `parameters=[twist_mux_params_path]`: `twist_mux` の挙動（どのトピックを購読するか、優先度はどうするか等）を定義した設定ファイルを渡します。
-   `remappings=[('/cmd_vel_out', '/cmd_vel')]`: トピックのリマッピング（名前変更）機能です。`twist_mux` ノードは、デフォルトでは `/cmd_vel_out` という名前で最終的な速度指令をパブリッシュしますが、ROSの慣習では `/cmd_vel` が一般的に使われます。この設定により、出力トピック名を `/cmd_vel` に変更し、他のノード（この場合は `azimuth_commander_node`）が接続しやすくしています。

#### 4.5.4. `azimuth_commander_node` と `f7_interface_node`

```python
        # 4. azimuth_commander_node
        Node(
            package='azimuth_teleop',
            executable='azimuth_commander_node',
            name='azimuth_commander_node',
            output='screen',
            parameters=[teleop_params_path]
        ),
        
        # 5. f7_interface_node
        Node(
            package='azimuth_teleop',
            executable='f7_interface_node',
            name='f7_interface_node',
            output='screen'
        )
```

-   これらは自作のノードで、それぞれ必要な設定ファイルを `parameters` として渡して起動しています。
-   `f7_interface_node` は、現在の実装ではIPアドレスなどがハードコードされているため、パラメータを渡していません。