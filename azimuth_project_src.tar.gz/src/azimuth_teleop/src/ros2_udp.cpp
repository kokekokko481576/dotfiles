#include "azimuth_teleop/ros2_udp.hpp"

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#include <cstdint>
#include <cstring>
#include <string>

/**
 * @brief Ros2UDPクラスのコンストラクタ実装。
 */
Ros2UDP::Ros2UDP(const std::string &f7_address, int f7_port) {
  // UDP通信用のソケットを作成します。
  // AF_INET: IPv4 インターネットプロトコル
  // SOCK_DGRAM: データグラムソケット (UDP)
  // 0: プロトコルは自動選択
  sock = socket(AF_INET, SOCK_DGRAM, 0);

  // 送信先のアドレス情報を設定します。
  f7_addr.sin_family = AF_INET;  // プロトコルファミリをIPv4に設定
  f7_addr.sin_port =
      htons(f7_port);  // ポート番号をネットワークバイトオーダーに変換
  f7_addr.sin_addr.s_addr =
      inet_addr(f7_address.c_str());  // IPアドレス文字列をバイナリ形式に変換
}

/**
 * @brief ソケットにアドレスをバインドします（現在未使用）。
 */
void Ros2UDP::udp_bind() {
  bind(sock, (const struct sockaddr *)&f7_addr, sizeof(f7_addr));
}

/**
 * @brief UDPパケットを送信する関数の実装。
 */
ssize_t Ros2UDP::send_packet(uint8_t *packet, size_t size) {
  // sendtoシステムコールを使用して、コンストラクタで設定したアドレスに
  // UDPパケットを送信します。
  return sendto(sock, packet, size, 0, (struct sockaddr *)&f7_addr,
                sizeof(f7_addr));
}

/**
 * @brief UDPパケットを受信する関数の実装（現在未使用）。
 */
ssize_t Ros2UDP::udp_recv(uint8_t *buf, size_t size) {
  // 受信バッファをゼロクリアします。
  memset(buf, 0, size);
  // recvシステムコールを使用してデータを受信します。
  return recv(sock, buf, size, 0);
}