/**
 * @file manual_teleop_node.cpp
 * @brief ジョイスティック入力に基づいて艦船を手動操縦するためのROS 2ノード。
 *
 * このノードは /joy トピックを購読し、ジョイスティックの軸とボタンのマッピングを
 * ROSパラメータから読み込みます。読み取った入力は線形速度と角速度の指令
 * (/cmd_vel_joy) に変換されます。また、自律モードへの切り替え、手動操作による
 * 自律モードのオーバーライド、および緊急停止機能も提供します。
 */

#include <cmath>
#include <vector>

#include "geometry_msgs/msg/twist.hpp"
#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/joy.hpp"
#include "std_msgs/msg/bool.hpp"
#include "std_msgs/msg/bool.hpp"

#include "std_msgs/msg/string.hpp"

/**
 * @class ManualTeleopNode
 * @brief ジョイスティックからの入力を速度指令に変換し、モード管理を行うクラス。
 */
class ManualTeleopNode : public rclcpp::Node {
 public:
  /**
   * @brief ManualTeleopNodeのコンストラクタ。
   *
   * ROSパラメータを宣言し、パブリッシャーとサブスクライバーを初期化します。
   * パラメータには、速度の最大値、軸・ボタンのマッピング、速度スケールなどが含まれます。
   */
  ManualTeleopNode() : Node("manual_teleop_node"), is_auto_mode_(false) {
    // === パラメータ宣言 ===
    // このノードの挙動は、launchファイルから渡されるYAMLファイルによって詳細に設定されます。

    // --- 共通パラメータ ---
    this->declare_parameter<double>("max_linear_speed", 1.0);  // [m/s]
    this->declare_parameter<double>("max_angular_speed", 1.57);  // [rad/s]

    // --- 軸マッピング (-1で無効) ---
    this->declare_parameter<int>("axis_linear_x", -1);   // 前後移動
    this->declare_parameter<int>("axis_linear_y", -1);   // 横移動
    this->declare_parameter<int>("axis_angular_z", -1);  // 旋回

    // --- ボタンマッピング (-1で無効) ---
    this->declare_parameter<int>("button_angular_z_positive",
                               -1);  // 右旋回ボタン
    this->declare_parameter<int>("button_angular_z_negative",
                               -1);  // 左旋回ボタン
    this->declare_parameter<int>("button_mode_toggle",
                               -1);  // 手動/自動モード切り替えボタン
    this->declare_parameter<int>("button_emergency_1",
                               -1);  // 緊急停止ボタン1
    this->declare_parameter<int>("button_emergency_2",
                               -1);  // 緊急停止ボタン2
    this->declare_parameter<int>("button_led_toggle", -1); // LED点灯ボタン

    // --- DPモード用ボタンマッピング ---
    this->declare_parameter<int>("button_dp_simple", -1); // シンプル版DPを起動
    this->declare_parameter<int>("button_dp_restricted", -1); // 角度制限版DPを起動

    // --- 速度スケーリング --- 
    // 特定のボタンを押している間だけ速度を落とす、などの用途に使用します。
    this->declare_parameter<double>("scale_linear", 1.0);
    this->declare_parameter<double>("scale_angular", 1.0);

    // === サブスクライバーとパブリッシャーの作成 ===
    joy_sub_ = this->create_subscription<sensor_msgs::msg::Joy>(
        "joy", 10,
        std::bind(&ManualTeleopNode::joy_callback, this,
                  std::placeholders::_1));

    cmd_vel_pub_ =
        this->create_publisher<geometry_msgs::msg::Twist>("/cmd_vel_joy", 10);
    auto_mode_pub_ = this->create_publisher<std_msgs::msg::Bool>(
        "/engage_station_keeping", 10);
    emergency_stop_pub_ = this->create_publisher<geometry_msgs::msg::Twist>(
        "/cmd_vel_emergency", 10);
    led_toggle_pub_ = this->create_publisher<std_msgs::msg::Bool>("/led_toggle", 10);
    dp_mode_pub_ = this->create_publisher<std_msgs::msg::String>("/dp_mode_request", 10);

    RCLCPP_INFO(
        this->get_logger(),
        "Manual Teleop Node has been started with parameter-based mapping.");
  }

 private:
  /**
   * @brief /joy トピックのコールバック関数。
   *
   * ジョイスティックの状態が更新されるたびに呼び出されます。
   * パラメータで指定されたマッピングに基づき、緊急停止、モード切替、
   * 手動操作指令の生成といった処理を優先度順に実行します。
   * @param msg 受信した sensor_msgs::msg::Joy メッセージ。
   */
  void joy_callback(const sensor_msgs::msg::Joy::SharedPtr msg) {
    // --- パラメータの取得 ---
    const int axis_linear_x = this->get_parameter("axis_linear_x").as_int();
    const int axis_linear_y = this->get_parameter("axis_linear_y").as_int();
    const int axis_angular_z = this->get_parameter("axis_angular_z").as_int();
    const int btn_angular_pos =
        this->get_parameter("button_angular_z_positive").as_int();
    const int btn_angular_neg =
        this->get_parameter("button_angular_z_negative").as_int();
    const int btn_mode_toggle =
        this->get_parameter("button_mode_toggle").as_int();
    const int btn_emergency_1 =
        this->get_parameter("button_emergency_1").as_int();
    const int btn_emergency_2 = 
        this->get_parameter("button_emergency_2").as_int();
    const int btn_led_toggle = this->get_parameter("button_led_toggle").as_int();
    const int btn_dp_simple = this->get_parameter("button_dp_simple").as_int();
    const int btn_dp_restricted = this->get_parameter("button_dp_restricted").as_int();

    // --- 安全チェック ---
    auto check_bounds = [&](int id, size_t size, const std::string& type) {
      if (id >= 0 && static_cast<size_t>(id) >= size) {
        RCLCPP_ERROR_ONCE(this->get_logger(),
                          "Parameter %s_id: %d is out of bounds for joy "
                          "message size %zu. Check controller config.",
                          type.c_str(), id, size);
        return false;
      }
      return true;
    };

    if (!check_bounds(axis_linear_x, msg->axes.size(), "axis_linear_x") ||
        !check_bounds(axis_linear_y, msg->axes.size(), "axis_linear_y") ||
        !check_bounds(axis_angular_z, msg->axes.size(), "axis_angular_z") ||
        !check_bounds(btn_angular_pos, msg->buttons.size(),
                      "btn_angular_pos") ||
        !check_bounds(btn_angular_neg, msg->buttons.size(),
                      "btn_angular_neg") ||
        !check_bounds(btn_mode_toggle, msg->buttons.size(),
                      "btn_mode_toggle") ||
        !check_bounds(btn_emergency_1, msg->buttons.size(),
                      "btn_emergency_1") ||
        !check_bounds(btn_emergency_2, msg->buttons.size(),
                      "btn_emergency_2") ||
        !check_bounds(btn_led_toggle, msg->buttons.size(), "btn_led_toggle") ||
        !check_bounds(btn_dp_simple, msg->buttons.size(), "btn_dp_simple") ||
        !check_bounds(btn_dp_restricted, msg->buttons.size(), "btn_dp_restricted")) {
      return;  // エラーがあればこの周期の処理を中断
    }

    // --- LED点灯ロジック ---
    if (btn_led_toggle >= 0 && msg->buttons[btn_led_toggle] == 1 && prev_led_toggle_button_state_ == 0) {
        is_led_on_ = !is_led_on_;
        auto led_msg = std::make_unique<std_msgs::msg::Bool>();
        led_msg->data = is_led_on_;
        led_toggle_pub_->publish(std::move(led_msg));
    }

    // --- 緊急停止ロジック (最優先) ---
    if (btn_emergency_1 >= 0 && btn_emergency_2 >= 0 &&
        msg->buttons[btn_emergency_1] == 1 &&
        msg->buttons[btn_emergency_2] == 1) {
      auto stop_msg = std::make_unique<geometry_msgs::msg::Twist>();
      emergency_stop_pub_->publish(std::move(stop_msg));
      RCLCPP_WARN(this->get_logger(), "EMERGENCY STOP ACTIVATED!");
      return;  // 緊急停止が作動したら、他の操作はすべて無視
    }

    // --- 現在の操作状態を判定 ---
    const bool is_operating =
        (axis_linear_x >= 0 && std::abs(msg->axes[axis_linear_x]) > 0.1) ||
        (axis_linear_y >= 0 && std::abs(msg->axes[axis_linear_y]) > 0.1) ||
        (axis_angular_z >= 0 && std::abs(msg->axes[axis_angular_z]) > 0.1) ||
        (btn_angular_pos >= 0 && msg->buttons[btn_angular_pos] == 1) ||
        (btn_angular_neg >= 0 && msg->buttons[btn_angular_neg] == 1);

    // --- モード切替ロジック ---
    auto engage_dp = [&](const std::string& mode_name) {
        if (!is_auto_mode_) {
            is_auto_mode_ = true;
            auto engage_msg = std::make_unique<std_msgs::msg::Bool>();
            engage_msg->data = true;
            auto_mode_pub_->publish(std::move(engage_msg));

            auto mode_msg = std::make_unique<std_msgs::msg::String>();
            mode_msg->data = mode_name;
            dp_mode_pub_->publish(std::move(mode_msg));

            RCLCPP_INFO(this->get_logger(), "Engaging DP Mode: %s", mode_name.c_str());
        }
    };

    if (btn_dp_simple >= 0 && msg->buttons[btn_dp_simple] == 1) {
        engage_dp("simple");
    }
    if (btn_dp_restricted >= 0 && msg->buttons[btn_dp_restricted] == 1) {
        engage_dp("restricted");
    }

    // --- 手動操作によるモード解除 ---
    if (is_auto_mode_ && is_operating) {
      is_auto_mode_ = false;
      auto engage_msg = std::make_unique<std_msgs::msg::Bool>();
      engage_msg->data = false;
      auto_mode_pub_->publish(std::move(engage_msg));
      RCLCPP_INFO(this->get_logger(),
                  "Disengaging Station Keeping Mode! Manual override.");
    }

    // --- 手動操作ロジック ---
    if (!is_auto_mode_) {
      if (is_operating) {
        auto twist_msg = std::make_unique<geometry_msgs::msg::Twist>();
        const double max_linear =
            this->get_parameter("max_linear_speed").as_double();
        const double max_angular =
            this->get_parameter("max_angular_speed").as_double();
        const double scale_linear =
            this->get_parameter("scale_linear").as_double();
        const double scale_angular =
            this->get_parameter("scale_angular").as_double();

        if (axis_linear_x >= 0) {
          twist_msg->linear.x =
              msg->axes[axis_linear_x] * max_linear * scale_linear;
        }
        if (axis_linear_y >= 0) {
          twist_msg->linear.y =
              msg->axes[axis_linear_y] * max_linear * scale_linear;
        }

        if (axis_angular_z >= 0) {
          twist_msg->angular.z =
              -msg->axes[axis_angular_z] * max_angular * scale_angular;
        } else {
          if (btn_angular_pos >= 0 && msg->buttons[btn_angular_pos] == 1) {
            twist_msg->angular.z = max_angular * scale_angular;
          } else if (btn_angular_neg >= 0 && msg->buttons[btn_angular_neg] == 1) {
            twist_msg->angular.z = -max_angular * scale_angular;
          }
        }
        cmd_vel_pub_->publish(std::move(twist_msg));
      } else if (prev_is_operating_) {
        // 操作が終わった瞬間に一度だけゼロ速度を送信
        auto twist_msg = std::make_unique<geometry_msgs::msg::Twist>();
        cmd_vel_pub_->publish(std::move(twist_msg));
        RCLCPP_INFO(this->get_logger(),
                    "Teleop input stopped, publishing zero velocities.");
      }
    }

    // --- 状態の保存 ---
    if (btn_led_toggle >= 0) {
        prev_led_toggle_button_state_ = msg->buttons[btn_led_toggle];
    }
    prev_is_operating_ = is_operating;
  }

  // === メンバ変数 ===
  //! ジョイスティックからの入力を受け取るサブスクライバー
  rclcpp::Subscription<sensor_msgs::msg::Joy>::SharedPtr joy_sub_;
  //! 手動操作による速度指令をパブリッシュするパブリッシャー
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_pub_;
  //! 自律モードの有効/無効を要求するパブリッシャー
  rclcpp::Publisher<std_msgs::msg::Bool>::SharedPtr auto_mode_pub_;
  //! 緊急停止用のゼロ速度指令をパブリッシュするパブリッシャー
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr emergency_stop_pub_;
  rclcpp::Publisher<std_msgs::msg::Bool>::SharedPtr led_toggle_pub_;
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr dp_mode_pub_;
  //! 現在が自律モードかどうかを保持するフラグ
  bool is_auto_mode_;
  bool is_led_on_;
  int prev_led_toggle_button_state_ = 0;
  bool prev_is_operating_ = false;
};

/**
 * @brief main関数
 * @param argc 引数の数
 * @param argv 引数
 * @return int 終了コード
 */
int main(int argc, char* argv[]) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<ManualTeleopNode>());
  rclcpp::shutdown();
  return 0;
}