/**
 * @file f7_interface_node.cpp
 * @brief ROS 2の世界とSTM32 F7マイコンをUDPで接続するブリッジノード。
 *
 * このノードは /azimuth_command (azimuth_teleop/msg/AzimuthControl) トピックを購読します。
 * 受信したROSメッセージを、STM32マイコンが解釈できる固定長のバイナリデータ構造体
 * (ControlData) に変換し、指定されたIPアドレスとポート番号にUDPパケットとして送信します。
 * これにより、高レベルのROSシステムと低レベルのハードウェア制御を分離します。
 */

#include <cerrno>
#include <cstring>

#include "azimuth_teleop/msg/azimuth_control.hpp"
#include "azimuth_teleop/ros2_udp.hpp"
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/bool.hpp"

/**
 * @struct ControlData
 * @brief STM32マイコンに送信するためのデータ構造体。
 * @warning この構造体のメンバ変数の【順番、型、サイズ】は、マイコン側の
 * ファームウェアで定義されている受信用の構造体と完全に一致させる必要があります。
 * どちらかに変更を加えた場合は、もう一方も必ず同期させてください。
 * 一致していない場合、データが破損したり、予期せぬ動作を引き起こす原因となります。
 */
struct __attribute__((packed)) ControlData {
  float target_rpm_l;
  float target_rpm_r;
  float target_angle_l;
  float target_angle_r;
  float target_bow_rpm_l;
  float target_bow_rpm_r;
  uint8_t led_state; // LEDの状態 (0: off, 1: on)
};

/**
 * @class F7InterfaceNode
 * @brief ROSメッセージを購読し、UDPパケットとして送信する機能を持つクラス。
 */
class F7InterfaceNode : public rclcpp::Node {
 public:
  /**
   * @brief F7InterfaceNodeのコンストラクタ。
   *
   * 送信先のIPアドレスとポート番号を設定し、UDP送信機を初期化します。
   * また、ROSメッセージを購読するためのサブスクライバーを作成します。
   */
  F7InterfaceNode() : Node("f7_interface_node") {
    // 注意: 現状、送信先のIPアドレスとポートはハードコードされています。
    // 将来的に、ROSパラメータから読み込むように変更することが望ましいです。
    const std::string STM32_IP = "192.168.0.101";
    const int STM32_PORT = 12345;

    // UDP送信機を作成
    udp_sender_ = std::make_unique<Ros2UDP>(STM32_IP, STM32_PORT);

        // サブスクライバーを作成
        manual_cmd_sub_ = this->create_subscription<azimuth_teleop::msg::AzimuthControl>(
            "/azimuth_command", 10, std::bind(&F7InterfaceNode::manualCommandCallback, this, std::placeholders::_1));
        dp_cmd_sub_ = this->create_subscription<azimuth_teleop::msg::AzimuthControl>(
            "/thruster_command", 10, std::bind(&F7InterfaceNode::dpCommandCallback, this, std::placeholders::_1));
        engage_sub_ = this->create_subscription<std_msgs::msg::Bool>(
            "/engage_station_keeping", 10, std::bind(&F7InterfaceNode::engageCallback, this, std::placeholders::_1));
    
        led_toggle_sub_ = this->create_subscription<std_msgs::msg::Bool>(
            "/led_toggle", 10, std::bind(&F7InterfaceNode::led_toggle_callback, this, std::placeholders::_1));
    
        is_dp_mode_ = false; // 初期状態は手動モード
    
        RCLCPP_INFO(this->get_logger(),
                    "F7 Interface Node has been started. Sending to %s:%d",
                    STM32_IP.c_str(), STM32_PORT);  }

 private:
  /**
   * @brief /azimuth_command トピックのコールバック関数。
   *
   * AzimuthControl メッセージを受信するたびに呼び出されます。
   * メッセージの内容を ControlData 構造体にコピーし、UDPで送信します。
   * @param msg 受信した azimuth_teleop::msg::AzimuthControl メッセージ。
   */
  void manualCommandCallback(const azimuth_teleop::msg::AzimuthControl::SharedPtr msg) {
    last_manual_cmd_ = msg;
    if (!is_dp_mode_) {
      send_udp_packet(msg);
    }
  }

  void dpCommandCallback(const azimuth_teleop::msg::AzimuthControl::SharedPtr msg) {
    last_dp_cmd_ = msg;
    if (is_dp_mode_) {
      send_udp_packet(msg);
    }
  }

  void engageCallback(const std_msgs::msg::Bool::SharedPtr msg) {
    is_dp_mode_ = msg->data;
  }

  void led_toggle_callback(const std_msgs::msg::Bool::SharedPtr msg) {
    led_state_ = msg->data ? 1 : 0;
    // DPモードかどうかに応じて、最後に受信した方の指令にLED状態を追記して再送
    if (is_dp_mode_ && last_dp_cmd_) {
        send_udp_packet(last_dp_cmd_);
    } else if (!is_dp_mode_ && last_manual_cmd_) {
        send_udp_packet(last_manual_cmd_);
    }
  }

  void send_udp_packet(const azimuth_teleop::msg::AzimuthControl::SharedPtr msg) {
    if (!msg) {
      return; 
    }

    ControlData packet_to_send;
    packet_to_send.target_rpm_l = msg->target_rpm_l;
    packet_to_send.target_rpm_r = msg->target_rpm_r;
    packet_to_send.target_angle_l = msg->target_angle_l;
    packet_to_send.target_angle_r = msg->target_angle_r;
    packet_to_send.target_bow_rpm_l = msg->target_bow_rpm_l;
    packet_to_send.target_bow_rpm_r = msg->target_bow_rpm_r;
    packet_to_send.led_state = led_state_;

    ssize_t sent_bytes = udp_sender_->send_packet(
        reinterpret_cast<uint8_t*>(&packet_to_send), sizeof(packet_to_send));

    if (sent_bytes < 0) {
      RCLCPP_ERROR(this->get_logger(), "Failed to send UDP packet: %s",
                   strerror(errno));
    }
  }

  // === メンバ変数 ===
  rclcpp::Subscription<azimuth_teleop::msg::AzimuthControl>::SharedPtr manual_cmd_sub_;
  rclcpp::Subscription<azimuth_teleop::msg::AzimuthControl>::SharedPtr dp_cmd_sub_;
  rclcpp::Subscription<std_msgs::msg::Bool>::SharedPtr engage_sub_;
  rclcpp::Subscription<std_msgs::msg::Bool>::SharedPtr led_toggle_sub_;
  std::unique_ptr<Ros2UDP> udp_sender_;
  uint8_t led_state_ = 0;
  bool is_dp_mode_;
  azimuth_teleop::msg::AzimuthControl::SharedPtr last_manual_cmd_;
  azimuth_teleop::msg::AzimuthControl::SharedPtr last_dp_cmd_;
};

/**
 * @brief main関数
 * @param argc 引数の数
 * @param argv 引数
 * @return int 終了コード
 */
int main(int argc, char* argv[]) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<F7InterfaceNode>());
  rclcpp::shutdown();
  return 0;
}