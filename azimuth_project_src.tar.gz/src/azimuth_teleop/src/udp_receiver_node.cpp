#include <iostream>
#include <cstring>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include "rclcpp/rclcpp.hpp"

class UdpReceiverNode : public rclcpp::Node {
public:
    UdpReceiverNode() : Node("udp_receiver_node") {
        const int port = 12346; // STM32からの応答を受信するポート

        sockfd_ = socket(AF_INET, SOCK_DGRAM, 0);
        if (sockfd_ < 0) {
            RCLCPP_ERROR(this->get_logger(), "Failed to create socket");
            return;
        }

        struct sockaddr_in servaddr;
        memset(&servaddr, 0, sizeof(servaddr));
        servaddr.sin_family = AF_INET;
        servaddr.sin_addr.s_addr = INADDR_ANY;
        servaddr.sin_port = htons(port);

        if (bind(sockfd_, (const struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {
            RCLCPP_ERROR(this->get_logger(), "Failed to bind socket");
            return;
        }

        RCLCPP_INFO(this->get_logger(), "UDP Receiver started on port %d", port);

        timer_ = this->create_wall_timer(
            std::chrono::milliseconds(10),
            std::bind(&UdpReceiverNode::receive_packet, this));
    }

    ~UdpReceiverNode() {
        if (sockfd_ >= 0) {
            close(sockfd_);
        }
    }

private:
    void receive_packet() {
        char buffer[1024];
        struct sockaddr_in cliaddr;
        socklen_t len = sizeof(cliaddr);
        ssize_t n = recvfrom(sockfd_, (char *)buffer, sizeof(buffer), MSG_DONTWAIT, (struct sockaddr *) &cliaddr, &len);

        if (n > 0) {
            buffer[n] = '\0';
            RCLCPP_INFO(this->get_logger(), "Received from %s:%d - %s", inet_ntoa(cliaddr.sin_addr), ntohs(cliaddr.sin_port), buffer);
        }
    }

    int sockfd_;
    rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char *argv[]) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<UdpReceiverNode>());
    rclcpp::shutdown();
    return 0;
}
