#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "std_msgs/msg/bool.hpp"
#include "std_msgs/msg/string.hpp"
#include "azimuth_teleop/msg/azimuth_control.hpp"
#include "azimuth_teleop/dp_algorithms.hpp"

class DpAllocatorNode : public rclcpp::Node {
 public:
  DpAllocatorNode() : Node("dp_allocator_node"), is_dp_mode_(false), last_pose_time_(0, 0, this->get_clock()->get_clock_type()) {
    // Subscribers
    engage_sub_ = this->create_subscription<std_msgs::msg::Bool>(
        "/engage_station_keeping", 10, std::bind(&DpAllocatorNode::engageCallback, this, std::placeholders::_1));
    mode_sub_ = this->create_subscription<std_msgs::msg::String>(
        "/dp_mode_request", 10, std::bind(&DpAllocatorNode::modeCallback, this, std::placeholders::_1));
    pose_sub_ = this->create_subscription<geometry_msgs::msg::PoseStamped>(
        "/gnss_pose", 10, std::bind(&DpAllocatorNode::poseCallback, this, std::placeholders::_1));

    // Publisher
    thruster_pub_ = this->create_publisher<azimuth_teleop::msg::AzimuthControl>("/thruster_command", 10);

    // PID controllers
    pid_x_ = std::make_unique<PID>(1.0, 0.1, 0.2); // Gains are placeholders
    pid_y_ = std::make_unique<PID>(1.0, 0.1, 0.2);
    pid_psi_ = std::make_unique<PID>(0.5, 0.05, 0.1);

    // Timer for control loop
    timer_ = this->create_wall_timer(
        std::chrono::milliseconds(100), std::bind(&DpAllocatorNode::controlLoop, this));

    RCLCPP_INFO(this->get_logger(), "DP Allocator Node started.");
  }

 private:
  void engageCallback(const std_msgs::msg::Bool::SharedPtr msg) {
    if (msg->data && !is_dp_mode_) {
      // DPモードに移行
      if (last_pose_time_.seconds() == 0 || (this->get_clock()->now() - last_pose_time_).seconds() > 1.0) {
        RCLCPP_WARN(this->get_logger(), "Cannot engage DP mode. No valid GNSS data received recently.");
        return;
      }
      is_dp_mode_ = true;
      target_pose_ = current_pose_;
      pid_x_->reset();
      pid_y_->reset();
      pid_psi_->reset();
      RCLCPP_INFO(this->get_logger(), "DP mode ENGAGED. Target set to current pose.");
    } else if (!msg->data && is_dp_mode_) {
      // 手動モードに移行
      is_dp_mode_ = false;
      RCLCPP_INFO(this->get_logger(), "DP mode DISENGAGED.");
    }
  }

  void modeCallback(const std_msgs::msg::String::SharedPtr msg) {
    current_algorithm_ = msg->data;
    RCLCPP_INFO(this->get_logger(), "DP algorithm set to: %s", current_algorithm_.c_str());
  }

  void poseCallback(const geometry_msgs::msg::PoseStamped::SharedPtr msg) {
    current_pose_ = *msg;
    last_pose_time_ = this->get_clock()->now();
  }

  void controlLoop() {
    if (!is_dp_mode_) {
      return; // DPモードでなければ何もしない
    }

    // --- 位置と方位の誤差を計算 ---
    double error_x = target_pose_.pose.position.x - current_pose_.pose.position.x;
    double error_y = target_pose_.pose.position.y - current_pose_.pose.position.y;
    // TODO: 方位(quaternion)の差を正しく計算する
    double error_psi = 0.0; 

    // --- PID制御 ---
    double dt = 0.1; // 10Hz
    double force_x = pid_x_->compute(error_x, 0, dt);
    double force_y = pid_y_->compute(error_y, 0, dt);
    double torque_z = pid_psi_->compute(error_psi, 0, dt);

    Eigen::Vector3d tau(force_x, force_y, torque_z);
    Eigen::VectorXd T;

    // --- 推力配分 ---
    if (current_algorithm_ == "restricted") {
      T = calculate_thrust_restricted(tau);
    } else {
      T = calculate_thrust_simple(tau);
    }

    // --- AzimuthControlメッセージに変換してPublish ---
    auto msg = azimuth_teleop::msg::AzimuthControl();
    // この変換ロジックはazimuth_commander_nodeから持ってくる必要がある
    // 今回はダミー実装
    msg.target_rpm_l = T.size() > 5 ? T(5) : 0.0;
    msg.target_angle_l = T.size() > 4 ? T(4) : 0.0;
    // ... 他のスラスターも同様に設定 ...
    thruster_pub_->publish(msg);
  }

  rclcpp::Subscription<std_msgs::msg::Bool>::SharedPtr engage_sub_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr mode_sub_;
  rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr pose_sub_;
  rclcpp::Publisher<azimuth_teleop::msg::AzimuthControl>::SharedPtr thruster_pub_;
  rclcpp::TimerBase::SharedPtr timer_;

  bool is_dp_mode_;
  std::string current_algorithm_ = "simple";
  geometry_msgs::msg::PoseStamped current_pose_;
  geometry_msgs::msg::PoseStamped target_pose_;
  rclcpp::Time last_pose_time_;

  std::unique_ptr<PID> pid_x_;
  std::unique_ptr<PID> pid_y_;
  std::unique_ptr<PID> pid_psi_;
};

int main(int argc, char* argv[]) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<DpAllocatorNode>());
  rclcpp::shutdown();
  return 0;
}