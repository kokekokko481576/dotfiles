/**
 * @file azimuth_commander_node.cpp
 * @brief 抽象的な速度指令を具体的なスラスター指令に変換するROS 2ノード。
 *
 * このノードは /cmd_vel トピック (geometry_msgs/msg/Twist) を購読し、
 * 船全体の並進速度・回転速度指令を受け取ります。
 * 受け取った指令と、ROSパラメータから読み込んだ船の物理的な設定値（スラスターの
 * 位置など）に基づいて、各アジマススラスターとバウスラスターが達成すべき
 * RPM（回転数）と角度を計算します。
 * 計算結果は /azimuth_command (azimuth_teleop/msg/AzimuthControl) トピックとして
 * パブリッシュされます。
 */

#include <cmath>

#include "azimuth_teleop/msg/azimuth_control.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "rclcpp/rclcpp.hpp"

/**
 * @class AzimuthCommanderNode
 * @brief 速度指令をスラスター指令に変換する計算ロジックを実装したクラス。
 */
class AzimuthCommanderNode : public rclcpp::Node {
 public:
  /**
   * @brief AzimuthCommanderNodeのコンストラクタ。
   *
   * 船の物理パラメータをROSパラメータとして宣言し、パブリッシャーと
   * サブスクライバーを初期化します。
   */
  AzimuthCommanderNode() : Node("azimuth_commander_node") {
    // === パラメータ宣言 ===
    // 船の物理的なジオメトリや変換係数を設定します。

    this->declare_parameter<double>(
        "thruster_distance",
        0.5);  // 船の中心から左右の主機スラスターまでの距離 [m]
    this->declare_parameter<double>(
        "vel_to_rpm_ratio",
        1000.0);  // 速度 [m/s] をRPMに変換するための係数
    this->declare_parameter<double>(
        "bow_thruster_distance",
        1.0);  // 船の中心からバウスラスターまでの距離 [m]

    // === サブスクライバーとパブリッシャーの作成 ===
    cmd_vel_sub_ = this->create_subscription<geometry_msgs::msg::Twist>(
        "cmd_vel", 10,
        std::bind(&AzimuthCommanderNode::cmd_vel_callback, this,
                  std::placeholders::_1));
    azimuth_cmd_pub_ =
        this->create_publisher<azimuth_teleop::msg::AzimuthControl>(
            "azimuth_command", 10);
    RCLCPP_INFO(this->get_logger(), "Azimuth Commander Node has been started.");
  }

 private:
  /**
   * @brief /cmd_vel トピックのコールバック関数。
   *
   * Twistメッセージを受け取り、各スラスターのRPMと角度を計算してパブリッシュします。
   * @param msg 受信した geometry_msgs::msg::Twist メッセージ。
   */
  void cmd_vel_callback(const geometry_msgs::msg::Twist::SharedPtr msg) {
    // --- 指令値を変数に格納 ---
    const double linear_x = msg->linear.x;    // 前後方向の並進速度
    const double linear_y = msg->linear.y;    // 横方向の並進速度
    const double angular_z = msg->angular.z;  // Z軸周りの回転角速度

    auto cmd = azimuth_teleop::msg::AzimuthControl();

    // --- デッドバンド処理 ---
    // 入力が非常に小さい場合は、ノイズとみなしてゼロ指令を出力する
    if (std::abs(linear_x) < 1e-6 && std::abs(linear_y) < 1e-6 && std::abs(angular_z) < 1e-6) {
        azimuth_cmd_pub_->publish(cmd); // メンバ変数はデフォルトでゼロ初期化される
        return;
    }

    // --- パラメータを取得 ---
    const double d = this->get_parameter("thruster_distance").as_double();
    const double vel_to_rpm =
        this->get_parameter("vel_to_rpm_ratio").as_double();
    const double bow_d =
        this->get_parameter("bow_thruster_distance").as_double();

    // === 主機スラスターの計算 ===
    // 船全体の並進・回転運動を実現するために、左右の主機スラスターが
    // それぞれ担当すべき速度ベクトルを計算します。
    double thrust_lx = linear_x - angular_z * d; // 左主機のX方向推力
    double thrust_ly = linear_y;                 // 左主機のY方向推力
    double thrust_rx = linear_x + angular_z * d; // 右主機のX方向推力
    double thrust_ry = linear_y;                 // 右主機のY方向推力

    // 速度ベクトルを極座標（角度と大きさ）に変換し、指令値を生成します。
    // 基準点を船の前方(ROS標準)から後方(船舶の慣例)に180度回転させるため、
    // atan2の引数の符号を反転させます。

    // 左主機の計算
    double left_thrust_magnitude = std::hypot(thrust_lx, thrust_ly);
    if (left_thrust_magnitude < 1e-6) {
      cmd.target_angle_l = 0.0;
    } else {
      cmd.target_angle_l =
          std::atan2(-thrust_ly, -thrust_lx) * 180.0 / M_PI;  // 左主機の目標角度 [deg]
    }
    cmd.target_rpm_l = left_thrust_magnitude * vel_to_rpm;  // 左主機の目標RPM

    // 右主機の計算
    double right_thrust_magnitude = std::hypot(thrust_rx, thrust_ry);
    if (right_thrust_magnitude < 1e-6) {
      cmd.target_angle_r = 0.0;
    } else {
      cmd.target_angle_r =
          std::atan2(-thrust_ry, -thrust_rx) * 180.0 / M_PI;  // 右主機の目標角度 [deg]
    }
    cmd.target_rpm_r = right_thrust_magnitude * vel_to_rpm;  // 右主機の目標RPM

    // === バウスラスターの計算 ===
    // バウスラスターは船首を左右に振る（Y軸方向の推力とZ軸周りの回転を補助する）
    // 役割を担います。
    // ここでは、横方向の並進速度と、回転によって生じる船首部分の接線速度を
    // 合成して、バウスラスターが担当すべき横方向の推力を計算します。
    double total_bow_thrust_y = linear_y + angular_z * bow_d;

    // 計算した推力をRPMに変換します。
    // 正の値は船首を右に、負の値は左に押す力に対応します。
    double final_bow_rpm = total_bow_thrust_y * vel_to_rpm;

    // 2つのバウスラスターは同じ指令値で動作させます。
    cmd.target_bow_rpm_l = final_bow_rpm;
    cmd.target_bow_rpm_r = final_bow_rpm;

    // --- 指令をパブリッシュ ---
    azimuth_cmd_pub_->publish(cmd);
  }

  // === メンバ変数 ===
  //! /cmd_vel を購読するサブスクライバー
  rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_sub_;
  //! 計算されたスラスター指令 /azimuth_command をパブリッシュするパブリッシャー
  rclcpp::Publisher<azimuth_teleop::msg::AzimuthControl>::SharedPtr
      azimuth_cmd_pub_;
};

/**
 * @brief main関数
 * @param argc 引数の数
 * @param argv 引数
 * @return int 終了コード
 */
int main(int argc, char *argv[]) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<AzimuthCommanderNode>());
  rclcpp::shutdown();
  return 0;
}