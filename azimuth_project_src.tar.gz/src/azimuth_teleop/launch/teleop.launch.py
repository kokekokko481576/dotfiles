import os
import glob
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, GroupAction, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch.conditions import IfCondition
from launch_ros.actions import Node

# evdevライブラリをインポート
try:
    import evdev
except ImportError:
    print("==================================================================================")
    print("evdevライブラリが見つかりません！ 'pip install evdev' を実行してください。")
    print("==================================================================================")
    exit()

def generate_launch_description():
    azimuth_teleop_pkg_share = get_package_share_directory('azimuth_teleop')
    ublox_gps_pkg_share = get_package_share_directory('ublox_gps')

    # --- コントローラー自動検出ロジック ---
    default_joy_config_name = 'hori.yaml'
    joy_device_name = None # joy_nodeに渡すデバイス名

    try:
        devices = [evdev.InputDevice(path) for path in evdev.list_devices()]
        for device in devices:
            device_name_lower = device.name.lower()
            
            # HORI
            if 'hori' in device_name_lower:
                print(f"INFO: HORIコントローラーを発見: {device.name}")
                default_joy_config_name = 'hori.yaml'
                joy_device_name = device.name
                break
            # 8BitDo
            elif '8bitdo' in device_name_lower:
                print(f"INFO: 8BitDoコントローラーを発見: {device.name}")
                default_joy_config_name = '8bitdo.yaml'
                joy_device_name = device.name
                break
            # BIGBIG WON (Xbox)
            elif device.info.vendor == 0x045e and device.info.product == 0x02e0:
                print(f"INFO: BIGBIG WON (Xbox互換) コントローラーを発見: {device.name}")
                default_joy_config_name = 'bigbig_won.yaml'
                joy_device_name = device.name
                break
    except Exception as e:
        print(f"WARN: evdevによるデバイス検出に失敗: {e}")

    if not joy_device_name:
        print("WARN: 知ってるコントローラーは見つからず。joy_nodeのデフォルトに任せます。")

    # --- 設定ファイルのパスを確定 ---
    joy_config_path = os.path.join(azimuth_teleop_pkg_share, 'config', default_joy_config_name)
    twist_mux_params_path = os.path.join(azimuth_teleop_pkg_share, 'config', 'twist_mux.yaml')
    teleop_params_path = os.path.join(azimuth_teleop_pkg_share, 'config', 'teleop_params.yaml')

    # --- joy_node のパラメータ ---
    joy_params = [joy_config_path]
    if joy_device_name:
        joy_params.append({'dev_name': joy_device_name})

    # --- Launch Argument の宣言 ---
    launch_joy_arg = DeclareLaunchArgument(
        'launch_joy',
        default_value='true',
        description='Set to "false" to disable launching joy_node (for remote operation)'
    )

    # --- ノード構成 ---
    return LaunchDescription([
        launch_joy_arg,

        # 1. joy_node (launch_joyが'true'の場合のみ起動)
        GroupAction(
            condition=IfCondition(LaunchConfiguration('launch_joy')),
            actions=[
                Node(
                    package='joy',
                    executable='joy_node',
                    name='joy_node',
                    parameters=joy_params
                )
            ]
        ),
        
        # 2. manual_teleop_node
        Node(
            package='azimuth_teleop',
            executable='manual_teleop_node',
            name='manual_teleop_node',
            output='screen',
            parameters=[joy_config_path, teleop_params_path]
        ),
        
        # 3. twist_mux
        Node(
            package='twist_mux',
            executable='twist_mux',
            name='twist_mux',
            parameters=[twist_mux_params_path],
            remappings=[('/cmd_vel_out', '/cmd_vel')]
        ),
        
        # 4. azimuth_commander_node
        Node(
            package='azimuth_teleop',
            executable='azimuth_commander_node',
            name='azimuth_commander_node',
            output='screen',
            parameters=[teleop_params_path]
        ),
        
        # 5. f7_interface_node
        Node(
            package='azimuth_teleop',
            executable='f7_interface_node',
            name='f7_interface_node',
            output='screen'
        ),

        # 6. dp_allocator_node
        Node(
            package='azimuth_teleop',
            executable='dp_allocator_node',
            name='dp_allocator_node',
            output='screen'
        ),

        # 7. ublox_gps
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(get_package_share_directory('azimuth_gnss'), 'launch', 'azimuth_gnss_node-launch.py')
            )
        ),

        # 8. gnss_converter_node
        Node(
            package='azimuth_gnss',
            executable='gnss_converter_node',
            name='gnss_converter_node',
            output='screen'
        )
    ])