#ifndef DP_ALGORITHMS_HPP_
#define DP_ALGORITHMS_HPP_

#include <iostream>
#include <vector>
#include <cmath>
#include <Eigen/Dense>

// 共通して使用するPIDクラス
class PID {
private:
    double Kp, Ki, Kd;
    double integral;
    double prev_error;

public:
    PID(double Kp_, double Ki_, double Kd_)
        : Kp(Kp_), Ki(Ki_), Kd(Kd_), integral(0.0), prev_error(0.0) {}

    double compute(double setpoint, double measured, double dt) {
        double error = setpoint - measured;
        integral += error * dt;
        double derivative = (error - prev_error) / dt;
        prev_error = error;
        return Kp * error + Ki * integral + Kd * derivative;
    }
    void reset() {
        integral = 0.0;
        prev_error = 0.0;
    }
};

// 共通して使用するShip構造体 (DP計算用)
struct DPShipModel {
    double x3, y3, x4, y4; // アジマススラスターのモーメントアーム計算用

    void set_thruster_positions(double theta3, double theta4) {
        x3 = -0.7517 - 0.027 * cos(theta3);
        y3 = 0.085 + 0.027 * sin(theta3);
        x4 = -0.7517 - 0.027 * cos(theta4);
        y4 = -0.085 + 0.027 * sin(theta4);
    }
};


// アルゴリズム1: シンプルな推力配分
inline Eigen::VectorXd calculate_thrust_simple(const Eigen::Vector3d& tau)
{
    double x1 = 0.6893;
    double x2 = 0.6443;
    
    DPShipModel ship;
    ship.set_thruster_positions(M_PI, M_PI * 2); // 仮の角度

    Eigen::Matrix<double, 3, 8> A;
    A << 0, 0, 0, 0, 1, 0, 1, 0,
         0, 1, 0, 1, 0, 1, 0, 1,
         0, x1, 0, x2, -(ship.y3), ship.x3, -(ship.y4), ship.x4;

    // 疑似逆行列を計算 (A^T * (A * A^T)^-1)
    Eigen::Matrix<double, 8, 3> A_pinv = A.completeOrthogonalDecomposition().pseudoInverse();
    
    Eigen::VectorXd T = A_pinv * tau;
    return T;
}

// アルゴリズム2: 角度制限ありの推力配分
inline Eigen::VectorXd calculate_thrust_restricted(const Eigen::Vector3d& tau)
{
    double x1 = 0.6893;
    double x2 = 0.6443;
    DPShipModel ship;
    ship.set_thruster_positions(M_PI, M_PI); // 仮の角度

    Eigen::Matrix<double, 3, 8> A;
    A << 0, 0, 0, 0, 1, 0, 1, 0,
         0, 1, 0, 1, 0, 1, 0, 1,
         0, x1, 0, x2, -(ship.y3), ship.x3, -(ship.y4), ship.x4;

    int n = 4;
    int p = 2 * n - 3;

    Eigen::BDCSVD<Eigen::MatrixXd> svd(A, Eigen::ComputeFullU | Eigen::ComputeFullV);
    Eigen::MatrixXd U = svd.matrixU();
    Eigen::MatrixXd V = svd.matrixV();
    Eigen::VectorXd s = svd.singularValues();
    Eigen::MatrixXd Sigma1_inv = Eigen::MatrixXd::Zero(3, 3);
    Sigma1_inv.diagonal() = s.head(3).cwiseInverse();
    Eigen::MatrixXd V1 = V.leftCols(3);
    Eigen::MatrixXd V2 = V.rightCols(p);

    std::vector<std::pair<double, double>> delta_bounds = {
        {M_PI*0.5, M_PI*0.5}, {M_PI*0.5, M_PI*0.5},
        {-M_PI*0.25, M_PI*0.25}, {-M_PI*0.25, M_PI*0.25}
    };

    Eigen::MatrixXd Bex(3 * n, p);
    Eigen::MatrixXd Dex(3 * n, 3);
    int r = 0;
    for (int i = 0; i < n; ++i) {
        double tan_l = tan(delta_bounds[i].first);
        double tan_u = tan(delta_bounds[i].second);
        Bex.row(r) = V2.row(2 * i + 1) - V2.row(2 * i) * tan_u;
        Dex.row(r) = -V1.row(2 * i + 1) + V1.row(2 * i) * tan_u;
        r++;
        Bex.row(r) = -V2.row(2 * i + 1) + V2.row(2 * i) * tan_l;
        Dex.row(r) = V1.row(2 * i + 1) - V1.row(2 * i) * tan_l;
        r++;
        Bex.row(r) = -V2.row(2 * i);
        Dex.row(r) = V1.row(2 * i);
        r++;
    }

    std::vector<Eigen::Vector3d> taus;
    for (double fx : {-1.0, 1.0}) for (double fy : {-1.0, 1.0}) for (double mz : {-1.0, 1.0})
        taus.push_back(Eigen::Vector3d(fx, fy, mz));

    int m = 3 * n;
    Eigen::MatrixXd Ball(m * 8, p);
    Eigen::VectorXd ball_rhs(m * 8);
    for (int i = 0; i < 8; ++i) {
        Ball.block(i * m, 0, m, p) = Bex;
        ball_rhs.segment(i * m, m) = Dex * taus[i];
    }

    Eigen::MatrixXd BA = Ball;
    Eigen::VectorXd bA = ball_rhs;
    int total_constraints = BA.rows();
    Eigen::MatrixXd KKT(p + total_constraints, p + total_constraints);
    KKT.setZero();
    KKT.topLeftCorner(p, p).setIdentity();
    KKT.topRightCorner(p, total_constraints) = BA.transpose();
    KKT.bottomLeftCorner(total_constraints, p) = BA;
    Eigen::VectorXd rhs(p + total_constraints);
    rhs.setZero();
    rhs.tail(total_constraints) = bA;

    Eigen::VectorXd c_star = KKT.fullPivLu().solve(rhs);

    Eigen::VectorXd Tex = V1 * Sigma1_inv * U.transpose() * tau + V2 * c_star;
    return Tex;
}

#endif // DP_ALGORITHMS_HPP_
