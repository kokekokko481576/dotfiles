#ifndef _ROS2_UDP_HPP_
#define _ROS2_UDP_HPP_

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#include <cstring>
#include <string>

/**
 * @class Ros2UDP
 * @brief シンプルなUDP通信機能を提供するラッパークラス。
 *
 * 指定されたIPアドレスとポート番号に対して、UDPパケットの送受信を
 * 簡単に行うための基本的な機能を提供します。
 */
class Ros2UDP {
 public:
  /**
   * @brief コンストラクタ。
   *
   * ソケットを作成し、送信先のアドレス情報を設定します。
   * @param f7_address 送信先のIPアドレス (例: "192.168.1.100")。
   * @param f7_port 送信先のポート番号。
   */
  Ros2UDP(const std::string &f7_address, int f7_port);

  /**
   * @brief ソケットにアドレスをバインド（関連付け）します。
   * @deprecated この関数は現在使用されていません。送信のみの場合は不要です。
   */
  void udp_bind();

  /**
   * @brief UDPパケットを送信します。
   *
   * @param packet 送信するデータが格納されたバッファへのポインタ。
   * @param size 送信するデータのサイズ（バイト単位）。
   * @return ssize_t 送信に成功したバイト数。失敗した場合は-1。
   */
  ssize_t send_packet(uint8_t *packet, size_t size);

  /**
   * @brief UDPパケットを受信します。
   *
   * @deprecated この関数は現在実装されておらず、使用されていません。
   * @param buf 受信データ格納用のバッファへのポインタ。
   * @param size 受信バッファの最大サイズ。
   * @return ssize_t 受信したバイト数。失敗した場合は-1。
   */
  ssize_t udp_recv(uint8_t *buf, size_t size);

 private:
  //! ソケットファイルディスクリプタ
  int sock;
  //! 送信先のアドレス情報を格納する構造体
  struct sockaddr_in f7_addr;
};

#endif