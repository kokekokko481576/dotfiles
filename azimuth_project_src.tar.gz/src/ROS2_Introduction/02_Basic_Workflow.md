[⬅️ 第1部: ROS2の基本概念に戻る](./01_ROS2_Concepts.md)

---

# 第2部: 基本的な開発フローとコマンド

第1部ではROS2の概念を学びました。この第2部では、それらの概念を実際に操作するためのコマンドと、基本的な開発ワークフローを解説します。

開発は、一般的に「①コード編集 → ②ビルド → ③実行 → ④確認」というサイクルを繰り返します。ここでは、特に②〜④で使うコマンドを詳しく見ていきましょう。

```mermaid
graph TD
    A[① コード編集] --> B(② ビルド); 
    B --> C{③ 実行}; 
    C --> D{④ 確認}; 
    D --> A;

    subgraph "② ビルド"
        direction LR
        colcon[colcon build]
    end

    subgraph "③ 実行"
        direction LR
        run[ros2 run]
    end

    subgraph "④ 確認"
        direction LR
        list[ros2 node/topic list]
        echo[ros2 topic echo]
        rqtgraph[rqt_graph]
    end
```

---

## 1. 準備: ビルドと環境設定

ソースコードを編集しただけでは、ROS2は変更を認識できません。変更をシステムに反映させるための2つのステップが「ビルド」と「環境設定」です。

### `colcon build`

- **動機:** 「ソースコード（人間が読むテキスト）を、コンピュータが実行できる形式に変換したい」
- **意味:** `colcon` はROS2のビルドツールです。ワークスペース（`src`フォルダがある階層）でこのコマンドを実行すると、`src`内の全パッケージのソースコードがコンパイル・変換され、`install`ディレクトリに実行可能なファイルなどが生成されます。

```bash
# ワークスペースのルートディレクトリに移動
cd ~/ros2_workspaces/azimuth_project

# すべてのパッケージをビルド
colcon build
```

**便利なオプション:**
特定のパッケージだけを素早くビルドしたい場合は、`--packages-select` を使います。

```bash
# my_package_name という名前のパッケージだけをビルド
colcon build --packages-select my_package_name
```

### `source install/setup.bash` (bash) / `source install/setup.zsh` (zsh)

- **動機:** 「ビルドして生成された実行ファイルやパッケージの場所を、このターミナルに教えたい」
- **意味:** `source` コマンドは、指定されたファイルの内容を現在のシェル（ターミナル）環境に読み込ませる命令です。ROS2はビルド時に、`install/setup.bash` (bash用) や `install/setup.zsh` (zsh用) など、各シェルに対応した環境設定ファイルを生成します。これを読み込むことで、ターミナルはROS2関連のコマンドをどこから探せばよいか理解します。

> **補足: シェルとは？**
> ターミナルで私たちが入力したコマンドを解釈し、OSに伝えて実行させるプログラムが「シェル」です。Linuxの標準は `bash` (バッシュ) であることが多いですが、より高機能な `zsh` (ジーシェル) など、様々な種類があります。このガイドでは、代表的なこの2つについて説明します。

**bashユーザーの場合:**
```bash
# ワークスペースのルートディレクトリで実行
source install/setup.bash
```

**zshユーザーの場合:**
```zsh
# ワークスペースのルートディレクトリで実行
source install/setup.zsh
```

**重要:** このコマンドは**新しいターミナルを開くたびに実行する必要があります**。毎回入力するのが面倒な場合は、お使いのシェルの設定ファイルの末尾にこの行を追記しておくと、ターミナル起動時に自動で実行されます。

- **bashの場合:** `~/.bashrc` に `source <path_to_your_workspace>/install/setup.bash` を追記します。
- **zshの場合:** `~/.zshrc` に `source <path_to_your_workspace>/install/setup.zsh` を追記します。

---

## 2. 実行: ノードを動かす

### `ros2 run <package_name> <executable_name>`

- **動機:** 「特定のプログラム（ノード）を起動したい」
- **意味:** 指定したパッケージに含まれる、指定した名前の実行可能ファイルを起動するコマンドです。

```bash
# turtlesim_cpp パッケージの turtlesim_node というノードを起動する例
ros2 run turtlesim_cpp turtlesim_node
```

**補足: パッケージ名や実行可能ノード名を忘れた場合**

`ros2 run <package_name> <executable_name>` を使うとき、正確なパッケージ名や、特に **実行可能ノード名 (`executable_name`)** を忘れてしまうことはよくあります。その場合は、以下のコマンドで一覧を確認できます。

- **`ros2 pkg list`**: 現在の環境で利用可能な全てのパッケージ名を出力します。たくさんありすぎる場合は `| grep <keyword>` で絞り込めます。

- **`ros2 pkg executables <package_name>`**: こちらが特に重要です。指定したパッケージに含まれている、**実行可能なノード (`executable_name`) の名前**を全て出力します。`ros2 run`の第二引数には、このコマンドで表示された名前を指定します。

```bash
# 利用可能な全パッケージをリストアップ
ros2 pkg list

# "turtlesim"という単語が含まれるパッケージに絞り込んで表示
ros2 pkg list | grep turtlesim

# turtlesim_cpp パッケージに含まれる実行可能ノード名をリストアップ
# このコマンドの出力が ros2 run で使う名前
ros2 pkg executables turtlesim_cpp
```

### 自分が今いるパッケージの実行可能ノードを知りたい場合

開発中のパッケージにいる場合、そのパッケージ名を指定して `ros2 pkg executables` を実行します。パッケージ名は通常、`package.xml` ファイルがあるディレクトリの名前と同じです。

```bash
# 例えば my_robot_controller というパッケージのディレクトリにいるなら...
# そのパッケージに含まれる実行可能ノードの一覧が表示される
ros2 pkg executables my_robot_controller
```

---

## 3. 観察: システムの状態を知る

ノードを起動したら、それが意図通りに動いているか、他のノードと通信できているかを確認します。

### `ros2 node list`

- **動機:** 「今、どんなプログラム（ノード）が起動しているか一覧で見たい」
- **意味:** 現在ROS2ネットワーク上で認識されている全てのノード名を表示します。

### `ros2 topic list`

- **動機:** 「ノード間で、どんな種類のデータ（トピック）がやり取りされているか知りたい」
- **意味:** 現在アクティブな全てのトピック名を表示します。

**便利なオプション:**
`-t` をつけると、各トピックのメッセージ型も一緒に表示してくれます。

```bash
$ ros2 topic list -t
/parameter_events [rcl_interfaces/msg/ParameterEvent]
/rosout [rcl_interfaces/msg/Log]
/turtle1/cmd_vel [geometry_msgs/msg/Twist]
/turtle1/color_sensor [turtlesim/msg/Color]
/turtle1/pose [turtlesim/msg/Pose]
```

---

## 4. 深掘り: データを覗く

トピックの存在を確認したら、次はその中を流れる実際のデータを見てみます。

### `ros2 topic echo <topic_name>`

- **動機:** 「特定のトピックを流れるデータを、リアルタイムで覗き見したい」
- **意味:** 指定したトピックを購読し、受信したメッセージをターミナルに表示し続けます。（Ctrl+Cで停止）

```bash
# /turtle1/pose トピックのデータを表示する例
$ ros2 topic echo /turtle1/pose
---
x: 5.544444561004639
y: 5.544444561004639
theta: 0.0
linear_velocity: 0.0
angular_velocity: 0.0
---
```
**topic名を忘れた場合**
```bash
~/ros2_workspaces/azimuth_project ..................................................................................................................................... 17m 20s 09:06:15
> ros2 topic list                 
/azimuth_command
/cmd_vel
/cmd_vel_auto
/cmd_vel_emergency
/cmd_vel_joy
/diagnostics
/engage_station_keeping
/joy
/joy/set_feedback
/parameter_events
/rosout


```

### `ros2 interface show <message_type_name>`

- **動機:** 「`echo`で見たデータの各項目が何なのか、その構造（設計図）を正確に知りたい」
- **意味:** 指定したメッセージ型の定義を表示します。`ros2 topic list -t` で調べた型名をここに指定します。

```bash
# turtlesim/msg/Pose という型の構造を表示する例
$ ros2 interface show turtlesim/msg/Pose
float32 x
float32 y
float32 theta

float32 linear_velocity
float32 angular_velocity
```

---

## 5. テスト: 手動でデータを送る

### `ros2 topic pub <topic> <msg_type> '<data>'`

- **動機:** 「あるノードをテストするために、手動でデータを送信して反応を見たい」
- **意味:** 指定したトピックに対し、指定した型のメッセージを1回だけ発行（Publish）します。データはYAML形式で記述します。

```bash
# /turtle1/cmd_vel トピックに、geometry_msgs/msg/Twist 型のデータを送信する例
# （直進1.0、回転0.5の速度指令）
ros2 topic pub /turtle1/cmd_vel geometry_msgs/msg/Twist '{linear: {x: 1.0}, angular: {z: 0.5}}'
```

**便利なオプション:**
`-r <rate>` をつけると、指定した周波数（Hz）でメッセージを繰り返し発行し続けてくれます。（Ctrl+Cで停止）

```bash
# 1秒間に1回 (1Hz) メッセージを送り続ける
ros2 topic pub -r 1 /turtle1/cmd_vel geometry_msgs/msg/Twist '{linear: {x: 1.0}}'
```

---

➡️ **[第3部: デバッグと可視化に進む](./03_Debugging_and_Visualization.md)**
