# 第1部: ROS2の基本概念

ROS2のコマンドやツールを使いこなすためには、まずROS2がどのような「考え方」や「設計思想」で作られているかを知ることが非常に重要です。

このドキュメントでは、ROS2の根幹をなす基本的な構成要素を、図を交えながら解説します。

---

## 1. ROS2とは？

ROS2 (Robot Operating System 2) は、ロボットアプリケーションを開発するための、オープンソースで柔軟なフレームワークです。

OSと名前がついていますが、WindowsやLinuxのようなOSそのものではなく、それらのOS上で動作するミドルウェアの一種です。ROS2は、複雑なロボットシステムを、**再利用可能な小さなプログラム（ノード）の集合体**として開発できるように設計されています。

## 2. 基本要素

### ノード (Node)

**ノードは、ROS2におけるプログラムの最小実行単位です。**

例えば、「カメラから映像を取得する」「モーターを制御する」「障害物を検知する」といった、単一の目的を持つ機能がそれぞれ一つのノードとして実装されます。

**なぜノードに分けるのか？**
- **再利用性**: 「障害物検知ノード」を一度作れば、別のロボットでも再利用できます。
- **独立性**: あるノードがクラッシュしても、他のノードは動き続けることができます（システム全体の堅牢性が向上）。
- **分業のしやすさ**: チームで開発する際に、「Aさんはカメラ担当」「Bさんはモーター担当」のように分担しやすくなります。

```mermaid
graph TD;
    subgraph Robot System
        Node1[Camera Node];
        Node2[Motor Control Node];
        Node3[Obstacle Detection Node];
        Node4[Path Planning Node];
    end
```

### トピック (Topic) と Publish/Subscribe モデル

**トピックは、ノード間でデータを継続的にやり取りするための「名前付きのバス（通り道）」です。**

ROS2の最も基本的な通信方法は、**Publish/Subscribe（出版/購読）モデル**と呼ばれます。

- **Publisher (出版者)**: データを生産し、特定のトピックへ向けて送信するノード。
- **Subscriber (購読者)**: 特定のトピックを購読し、データが来たら受信するノード。

これにより、各ノードは互いを直接知らなくても、トピックを介して疎結合に通信できます。Publisherは「誰が聞いているか」を気にせず、Subscriberは「誰が発信しているか」を気にしません。

```mermaid
graph TD;
    CameraNode[Camera Node] -- Publishes /image_raw --> Topic((/image_raw));
    Topic -- Data --> ObstacleDetectionNode[Obstacle Detection Node];
    Topic -- Data --> ImageViewerNode[Image Viewer Node];
```
*上の図では、`Camera Node`が`/image_raw`というトピックに映像データをPublishし、`Obstacle Detection Node`と`Image Viewer Node`がそれをSubscribeしてそれぞれの処理を行っています。*

### メッセージ (Message)

**メッセージは、トピックを介してやり取りされるデータの具体的な「型」や「構造」を定義したものです。**

例えば、速度指令を送るトピックでは、「前進方向に毎秒何メートル、回転方向に毎秒何ラジアン」といった情報が必要です。この構造を定義するのがメッセージです。

- `int32`, `float64`, `string` などの基本データ型や、他のメッセージを組み合わせて定義されます。
- 例: `geometry_msgs/msg/Twist` は、線形速度(`linear`)と角速度(`angular`)をそれぞれ3次元ベクトル(`Vector3`)で定義したメッセージ型です。

```
# geometry_msgs/msg/Vector3
float64 x
float64 y
float64 z
---
# geometry_msgs/msg/Twist
Vector3 linear
Vector3 angular
```

### サービス (Service)

**サービスは、同期的なリクエスト/レスポンス型の通信です。**

Publish/Subscribeモデルが一方通行のデータストリームであるのに対し、サービスは「お願い」をして「結果」を受け取る、という双方向の通信です。処理が終わるまで待つ（同期）のが特徴です。

- **Service Server**: 「お願い」を待ち受け、処理を実行して結果を返すノード。
- **Service Client**: Serverに「お願い」（リクエスト）を送り、結果（レスポンス）を待つノード。

**どんな時に使う？**
「計算して結果を返してほしい」「現在の設定値を教えてほしい」など、必ず返事が欲しい場合に使います。

```mermaid
sequenceDiagram
    participant Client
    participant Server
    Client->>Server: Request (例: 2つの数値を足して)
    activate Server
    Server-->>Client: Response (例: 計算結果)
    deactivate Server
```

### アクション (Action)

**アクションは、時間のかかるタスクを実行するための、非同期的なゴール指向の通信です。**

サービスと似ていますが、タスクの完了までに時間がかかる（例: 「目的地まで移動する」）場合に適しています。

- **Action Server**: ゴールを受け取り、タスクを実行する。実行中は定期的に**フィードバック**（途中経過）を送信し、最終的に**リザルト**（結果）を返す。
- **Action Client**: ゴールを送信し、フィードバックとリザルトを受け取る。非同期なので、結果を待つ間に別の処理も可能。

**どんな時に使う？**
「アームを特定の角度まで動かす」「指定した地点まで自律移動する」など、完了までに時間がかかり、途中経過も知りたいタスクに使います。

```mermaid
sequenceDiagram
    participant Client
    participant Server
    Client->>Server: Send Goal (例: 5秒間カウントアップして)
    Server-->>Client: Acknowledge Goal (受付完了)
    loop Feedback
        Server-->>Client: Feedback (例: 現在のカウント: 3)
    end
    Server->>Client: Send Result (例: 完了しました)
```

### パッケージとワークスペース

- **パッケージ (Package)**: 上記のノード、メッセージ、サービス、起動設定ファイルなどを一つのまとまりにしたものです。ROS2開発の基本的な単位です。
- **ワークスペース (Workspace)**: 複数のパッケージをまとめて管理するためのディレクトリです。通常、`src`ディレクトリに各パッケージのソースコードを配置します。

---

➡️ **[第2部: 基本的な開発フローとコマンドに進む](./02_Basic_Workflow.md)**