# Azimuth Project

ROS2を搭載した自律航行船「Azimuth」の制御用ワークスペースです。

## ドキュメント構成

この`README.md`には、プロジェクト全体の概要、基本的なセットアップ・実行方法、そして全体のメンテナンスログが記載されています。

各ROS 2パッケージ（`azimuth_teleop`など）の内部アーキテクチャ、ノード、トピック、設定ファイルといった詳細な技術ドキュメントについては、それぞれのパッケージディレクトリ内にある`README.md`を参照してください。

---

## 概要

このプロジェクトは、遠隔操作（Teleoperation）と動的位置決め（Dynamic Positioning）の機能を実装するためのROS2パッケージを含んでいます。

- **`azimuth_teleop`**: ジョイスティックコントローラーからの入力を受け取り、船の基本的な動作指令を生成します。詳細は `azimuth_teleop/README.md` を参照してください。
- **`ROS2_Introduction`**: ROS2の基本的な概念やワークフローに関するドキュメントが含まれています。

## セットアップ

#### 前提条件

- Ubuntu 22.04
- ROS 2 Humble Hawksbill (Desktop)

#### 手順

1.  **ROS 2関連パッケージのインストール**:
    ```bash
    sudo apt-get update
    sudo apt-get install ros-humble-joy-linux ros-humble-twist-mux
    ```

2.  **Pythonライブラリのインストール**:
    ```bash
    pip install evdev
    ```

3.  **ワークスペースの準備とソースコードの取得**:
    ```bash
    mkdir -p ~/ros2_workspaces/azimuth_project/src
    cd ~/ros2_workspaces/azimuth_project/src
    git clone <your-repository-url> .
    ```

4.  **ビルド**:
    ```bash
    cd ~/ros2_workspaces/azimuth_project
    colcon build
    ```

5.  **環境設定の読み込み**:
    ターミナルを開くたびに、または`~/.bashrc` (`zsh`をお使いの場合は `~/.zshrc`) に追記してください。

    - **bashの場合**:
      ```bash
      source ~/ros2_workspaces/azimuth_project/install/setup.bash
      ```

    - **zshの場合**:
      ```zsh
      source ~/ros2_workspaces/azimuth_project/install/setup.zsh
      ```

## 実行方法

新しいターミナルを開き、以下のコマンドを実行します。

```bash
ros2 launch azimuth_teleop teleop.launch.py
```

これにより、操縦に必要なすべてのノードが起動します。コントローラーが接続されていれば、すぐに操縦を開始できます。

---

## メンテナンスログ

このプロジェクトに重要な変更を加えた際は、ここに記録を残してください。

- **いつ (When):** 変更した日付 (YYYY-MM-DD)
- **誰が (Who):** 作業者の名前
- **何を (What):** 変更内容の簡潔な説明
- **なぜ (Why):** 変更理由

---

- **いつ (When):** 2025-11-12
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** Qiita記事を参考に`ublox_gps`パッケージのセットアップと`azimuth_gnss`パッケージへの統合
- **なぜ (Why):**
    - **目的**: `ublox_gps`パッケージをROS2ワークスペースに導入し、ZED-F9P GNSSレシーバーからのデータを受信できるようにするため。
    - **対応**:
        1.  `sudo apt install ros-humble-ublox`コマンドで`ublox`パッケージをシステムにインストール。
        2.  `src/azimuth_gnss/config`ディレクトリを作成。
        3.  `/opt/ros/humble/share/ublox_gps/config/zed_f9p.yaml`を`src/azimuth_gnss/config/azimuth_gnss.yaml`としてコピー。
        4.  `azimuth_gnss.yaml`を編集し、`baudrate: 230400`に設定し、`config_on_startup: false`を追加。
        5.  `src/azimuth_gnss/launch`ディレクトリを作成。
        6.  `/opt/ros/humble/share/ublox_gps/launch/ublox_gps_node-launch.py`を`src/azimuth_gnss/launch/azimuth_gnss_node-launch.py`としてコピー。
        7.  `azimuth_gnss_node-launch.py`を編集し、`azimuth_gnss`パッケージの`azimuth_gnss.yaml`を読み込むように修正。
        8.  `src/azimuth_gnss/package.xml`に`<depend>ublox_gps</depend>`を追加。
        9.  `src/azimuth_gnss/CMakeLists.txt`に`find_package(ublox_gps REQUIRED)`を追加し、`launch`および`config`ディレクトリをインストールする設定を追加。
        10. `colcon build --packages-select azimuth_gnss`で`azimuth_gnss`パッケージをビルド。
    - **結果**: `ublox_gps`パッケージが`azimuth_gnss`パッケージに統合され、ビルドが正常に完了した。これにより、ZED-F9PからのGNSSデータ受信の準備が整った。

---

- **いつ (When):** 2025-11-12
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** ネットワーク構成変更に伴い、ハードコードされたIPアドレスを修正。
- **なぜ (Why):**
    - **問題**: ローカルネットワークのセグメントが `192.168.21.x` から `192.168.0.x` に変更されたため、STM32マイコンとのUDP通信が機能しなくなった。
    - **対応**:
        1.  ワークスペース全体を `192.168.21.` で検索し、古いIPアドレスがハードコードされている箇所を特定。
        2.  `azimuth_teleop/src/f7_interface_node.cpp` 内で定義されていた送信先IPアドレスを、旧 `192.168.21.111` から新 `192.168.0.101` に修正した。
        3.  合わせて、関連するドキュメントファイル (`f7_interface_node.md`, `ros2_udp.md`) 内のIPアドレスの例も新しいものに更新した。
    - **結果**: これにより、新しいネットワーク構成でもROS 2 PCからSTM32マイコンへ正しくUDPパケットを送信できるようになったはず。

---

- **いつ (When):** 2025-11-07
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** コントローラーの不具合修正と、GNSS測位のトラブルシューティング
- **なぜ (Why):**
    - **問題1: コントローラーの指令値がおかしい**
        - **現象**: 何も操作していないのにスラスターの指令値が出力される。また、十字キーの前後移動の方向が逆。
        - **原因**:
            1.  `manual_teleop_node`がコントローラーの微小なノイズを拾い、ゼロでない速度指令を生成していた。
            2.  `manual_teleop_node`内で、前後・左右移動の計算時に符号が反転していた。
        - **対応**:
            1.  `azimuth_commander_node`にデッドバンド処理を追加し、微小な速度指令ではRPMがゼロになるように修正（フェイルセーフ）。
            2.  `manual_teleop_node`の符号を修正し、十字キーの操作方向を修正。
    - **問題2: GNSSの測位が安定しない (`gps_fix`が0のまま)**
        - **経緯**: 屋外環境にも関わらず、`gps_fix`が`0`のままで測位が開始されない問題が発生。
        - **調査**:
            -   `ublox_gps_node`が出力するトピック名がノード名のスコープに閉じており (`/ublox_gps_node/navpvt`)、他のノードから参照できない問題を`launch`ファイルの`namespace`設定で解決。
            -   `nav_rate`に関する警告ログが出ていたため、`rate: 1.0`を設定したが改善せず、最終的に元の設定に戻した。
            -   ROS側の設定を`gps_fix: 2`を一度達成した状態に完全に戻すことで、ソフトウェア的な問題を切り分けた。
        - **結果**: 最終的に、ソフトウェア構成を`gps_fix: 2`達成時と同一に戻したところ、**`gps_fix: 3` (3D測位) の達成に成功**した。
    - **残課題**:
        -   `gps_fix: 3`は達成できたものの、依然として`/navpvt`および`/gnss_pose`トピックにメッセージが流れない。原因は`ublox_gps_node`の内部的なpublish条件にあると推測され、引き続き調査が必要。

---

- **いつ (When):** 2025-11-07
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** GNSSベースの定点保持（DP）機能の統合と、GNSS無接続時のフォールバック対応
- **なぜ (Why):**
    - **目的**: `ublox_gps`パッケージからのGNSS測位情報 (`/navpvt`) を利用して、既存のDP（動的位置決め）機能を実際に動作させるため。また、GNSSが接続されていない状態でも、手動操縦など他の機能が問題なく利用できるようにするため。
    - **対応1: トピック変換ノードの追加**
        -   `ublox_gps_node`がpublishする`ublox_msgs/msg/NavPVT`型の`/navpvt`トピックを、`dp_allocator_node`が要求する`geometry_msgs/msg/PoseStamped`型の`/gnss_pose`トピックに変換する`gnss_converter_node`を`azimuth_gnss`パッケージに新規作成した。
    - **対応2: Launchファイルの統合**
        -   メインのlaunchファイルである`teleop.launch.py`に、`ublox_gps_node`と`gnss_converter_node`を起動する設定を追加。これにより、`ros2 launch`一発でDP機能を含む全システムが起動するようになった。
    - **対応3: GNSS無接続時のフォールバック**
        -   **問題**: GNSSレシーバーがPCに接続されていない場合、`ublox_gps_node`がエラーで終了し、それに伴い他の全ノードもシャットダウンしてしまう問題があった。
        -   **対策**:
            1.  `ublox_gps_node`が終了しても、システム全体はシャットダウンせず、警告ログを出すのみに変更 (`ublox_gps_node-launch.py`を修正)。
            2.  `dp_allocator_node`を修正し、GNSSデータが1秒以上受信されていない状態でDPモードを有効化しようとすると、警告ログを出してモード移行を拒否するようにした。
    - **結果**: GNSSの有無に応じて、システムの挙動がより堅牢になった。GNSS接続時はDP機能が利用可能になり、非接続時でも手動操縦機能は問題なく利用できる。

---

- **いつ (When):** 2025-11-07
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** ゼロ指令時にポッド角度を0に固定するよう `azimuth_commander_node` を修正。
- **なぜ (Why):**
    - **問題**: 操縦指令がない（速度がゼロ）場合に、計算誤差などでポッド角度が不定になる可能性があった。
    - **対応**: スラスターへの推力指令がほぼゼロの場合、角度計算を行わず、ポッド角度を明示的に0度（後方推力方向）に設定するロジックを追加した。
    - **結果**: 操縦していない待機状態では、ポッドが必ず基準の向きに戻るようになり、動作の安定性と予測可能性が向上した。

---

- **いつ (When):** 2025-11-07
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** コントローラー設定ファイル (`hori.yaml`, `8bitdo.yaml`) のインデックスずれを修正。
- **なぜ (Why):**
    - **問題**: `controller_mappings.txt` に記載されたボタン・軸の番号 (1から始まる) と、`yaml` ファイルに設定されたID (0から始まるべき) に不整合があり、多くの設定が1ずつズレていた。
    - **対応**: `txt` ファイルを正として、`hori.yaml` と `8bitdo.yaml` に設定されているすべての軸・ボタンIDを、正しい0-basedインデックスに修正した。
    - **結果**: これにより、コントローラーのすべてのボタンとスティックが設計通りに機能するようになり、意図しない動作を防ぐことができる。

---

- **いつ (When):** 2025-11-07
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** `azimuth_commander_node` のポッド角度の基準を「真後ろ=0度」に変更。
- **なぜ (Why):**
    - **問題**: `azimuth_commander_node` が計算するポッドの角度は、ROSの標準である「船の前方=0度」を基準としていた。しかし、船舶の慣例では「船の後方=0度」が一般的であり、ユーザーの直感と異なっていた。
    - **対応**: `atan2(y, x)` を `atan2(-y, -x)` に変更することで、角度の基準系を180度回転させた。
    - **結果**: これにより、最終的に出力されるポッドの角度が、ユーザーの求める「真後ろ=0度」という表現に修正され、直感的な制御とデバッグが可能になった。

- **いつ (When):** 2025-11-05
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** `ublox_gps` パッケージを利用したZED-F9P GNSSレシーバーからのデータ受信に成功
- **なぜ (Why):**
    - **経緯**: これまで`ublox_gps`パッケージの設定で多くの試行錯誤（`NACK`エラー、`FATAL`エラーなど）を重ねてきた。
    - **最終的な設定**:
        1. `azimuth_gnss.yaml`で、ZED-F9PのUSB接続における適切なボーレート `115200` を明示的に設定。
        2. ADR/UDR製品向けの機能である `setDeadReckonLimit` の呼び出しをソースコードレベルで無効化。
    - **結果**: 上記の修正により、`ublox_gps_node`が正常に起動し、ZED-F9Pから送信されるUBXメッセージの受信と解釈に成功。`/fix` トピックなどで有効な測位データ (`status: 0`以上) が得られるようになった。
    - **結論**: 適切なボーレート設定と、非対応機能の無効化が、`ublox_gps`パッケージとZED-F9Pの連携を成功させる鍵となった。

---

- **いつ (When):** 2025-11-12
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** u-blox GNSSレシーバーの動作確認について追記
- **なぜ (Why):**
    - **経緯**: `ublox_gps`パッケージを利用したGNSSレシーバーのデータ取得に関して、新たな知見が得られたため記録。
    - **内容**: [こちらのQiita記事](https://qiita.com/porizou1/items/87375394a6445952b9e9)に記載されている手順を参考に、`apt`で`ublox`関連のROSパッケージを導入し、Windows上の`u-center`アプリケーションでレシーバーの詳細設定を行ったところ、ROS2側でデータを正常に受信できることを確認した。
    - **今後の課題**: `u-center`で行った具体的な設定値の詳細は未整理のため、後日改めて設定を詰めてドキュメント化する必要がある。

---

- **いつ (When):** 2025-11-05
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** ZED-F9Pの`FATAL`エラー回避のため、`setDeadReckonLimit`の呼び出しを無効化
- **なぜ (Why):**
    - **問題**: ボーレート設定を修正後、`ros2 launch`すると`Failed to set dead reckoning limit`という`FATAL`エラーでノードがクラッシュするようになった。
    - **原因調査**: このエラーは、`ublox_gps_node`がDead Reckoning（推測航法）関連のパラメータを設定しようとして失敗していることを示している。この機能はADR/UDR製品向けのものであり、ZED-F9Pではサポートされていない。
    - **対応**: `ublox_gps`パッケージのソースコード (`src/node.cpp`) を直接編集し、`setDeadReckonLimit()`関数の呼び出し部分をコメントアウトした。これにより、サポートされていない機能の設定をスキップさせ、ノードが正常に起動できるようにする。

---

- **いつ (When):** 2025-11-05
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** ZED-F9Pのボーレート設定を明示的に変更
- **なぜ (Why):**
    - **問題**: `azimuth_gnss.yaml`で`uart1`セクションをコメントアウトしても、`ublox_gps_node`のログに`Configuring UART1 baud rate: 9600`と表示され、測位データが受信できない問題が継続。
    - **原因調査**: `ublox_gps_node.cpp`のソースコードを確認したところ、`uart1.baudrate`パラメータが明示的に設定されていない場合、ノードがデフォルトで`9600`bpsを使用することが判明。ZED-F9PのUSB接続ではこのボーレートは低すぎるため、データ受信に問題が生じていた可能性が高い。
    - **対応**: `azimuth_gnss.yaml`内の`uart1`セクションのコメントアウトを外し、`baudrate: 115200`を明示的に設定した。これはZED-F9PのUSBポートの一般的なボーレートであり、これにより正しい速度でデータ通信が行われることを期待する。

---

- **いつ (When):** 2025-11-05
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** ZED-F9P接続に合わせ、GNSS設定をリセットおよび簡素化
- **なぜ (Why):**
    - **状況の変化**: これまでNEO-D9Cを介していると想定していたが、ユーザーよりZED-F9Pを直接PCに接続しているとの情報を得たため、設定方針を全面的に見直し。
    - **問題**: ZED-F9Pを直接接続しているにも関わらず、依然として`NACK`エラーが解消されない。
    - **仮説**: これまでのトラブルシューティングで編集を重ねた`azimuth_gnss.yaml`に、不適切な設定が残っている、またはZED-F9PのUSB接続に対して過剰な設定となっている可能性がある。
    - **対応**: 
        1.  設定ファイルをクリーンな状態に戻すため、オリジナルの`zed_f9p.yaml`を`azimuth_gnss.yaml`に再度コピー。
        2.  USB接続であることを考慮し、UART接続用の`uart1`セクションをコメントアウト。
        3.  移動局として動作させるため、`tmode3` (Survey-In)を`0`に設定。
        4.  問題の切り分けのため、`publish`するメッセージを基本的な測位情報が含まれる`navpvt`のみに限定。
    - **目的**: 設定を可能な限りシンプルにすることで、`NACK`エラーの原因を特定し、ZED-F9Pとの基本的な通信を確立することを目指す。

---

- **いつ (When):** 2025-11-05
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** u-blox GNSSのNACKエラー対策として、起動時のコンフィグ送信を無効化
- **なぜ (Why):**
    - **問題**: `tmode3`を無効にしても、依然として`NACK`エラーと`status: -1` (NO_FIX) が解消されない。
    - **原因の再考察**: Web検索により、使用している`NEO-D9C`が単体のGNSSレシーバーではなく、「QZSS L6補正データ受信機」であることが判明。これは、`ublox_gps`パッケージが想定している標準的なGNSSレシーバーとは役割が異なるため、パッケージから送信される設定コマンドを正しく解釈できず、`NACK`を返している可能性が非常に高い。
    - **対応**: `azimuth_gnss.yaml`に`config_on_startup: false`を追加。これにより、`ublox_gps`ノードが起動時にデバイスへ設定コマンドを一切送信しないようにする（パッシブモード）。デバイスがデフォルトで何らかの測位情報を出力する設定になっていれば、このモードでデータを受信できる可能性がある。NACKエラーの根本原因であるコンフィグ送信自体を停止させ、問題の切り分けを行う。

---

- **いつ (When):** 2025-11-05
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** u-blox GNSSレシーバーのNACKエラーとNO_FIX問題のトラブルシューティング
- **なぜ (Why):**
    - **問題**: `ublox_gps`ノードを実行したところ、`NACK`エラーが多発し、`/fix`トピックの`status`が`-1` (NO_FIX) となる問題が発生した。
    - **原因調査**: ZED-F9P用の設定ファイル (`zed_f9p.yaml`) をベースにした`azimuth_gnss.yaml`を読み込んでいたが、ログに`Product category QZS from MonVER message not recognized`という警告が出ており、ドライバとデバイスのファームウェア間で何らかのミスマッチが起きている可能性が示唆された。
    - **仮説**: 設定ファイル内の`tmode3: 1` (Survey-Inモード) が有効になっていた。これは基地局(Base Station)として運用する際の設定であり、移動局(Rover)として単独で測位したい現在の状況には不適切である可能性が高いと判断。
    - **対応**: `azimuth_gnss.yaml`内の`tmode3`を`0`に設定変更し、関連する`sv_in`ブロックをコメントアウトした。これにより、デバイスを通常の移動局モードで起動させ、NACKエラーと測位失敗の解消を試みる。

---

- **いつ (When):** 2025-11-05
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** GNSSのROS1コード移植作業の失敗と現状復帰
- **なぜ (Why):**
    - **目的**: 先輩が作成した実績のあるROS1コード (`gnss_evk.cpp`) を、ROS2パッケージ (`azimuth_gnss`) として移植する。
    - **作業内容**:
        1. `ros2 pkg create` で `azimuth_gnss` パッケージの雛形を作成。
        2. ROS1の `.msg` ファイルを参考に、ROS2用のカスタムメッセージ (`GpsPosition.msg` 等) を作成。
        3. `gnss_evk.cpp` のロジック（シリアル通信、NMEAパーサー）を、新しい `azimuth_gnss_node.cpp` に移植。
    - **問題発生**: カスタムメッセージをビルドするための `CMakeLists.txt` の記述で、度重なるエラーが発生。
        - `ament_target_dependencies` や `target_link_libraries` の正しい使い方を特定できず、ビルドが全く通らない状況に陥った。
    - **最終的な対応**:
        - これ以上の試行錯誤は時間の浪費であると判断し、移植作業を一旦中断。
        - ワークスペース全体のビルドに影響を与えないよう、`azimuth_gnss` パッケージを **ビルドだけが通るクリーンな初期状態** に現状復帰させた。
        - 具体的には、`CMakeLists.txt`, `package.xml`, `azimuth_gnss_node.cpp` を初期化し、`msg` フォルダを削除した。
    - **結論**: GNSSのROS2対応は未完了。`CMakeLists.txt` の正しい記述方法を学習し、後日再挑戦する必要がある。

---

- **いつ (When):** 2025-11-05
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** GNSSレシーバーのROS2対応に関するデバッグと方針転換
- **なぜ (Why):**
    - **目的**: USB接続のGNSSレシーバーからのデータをROS2で受信すること。
    - **初期調査**: デバイスは `/dev/ttyACM0` として認識された。しかし `cat` コマンドではデータを確認できず、`dmesg` にも有用なログはなかった。
    - **方針1: `ublox_gps` パッケージの利用**
        - Qiitaの記事を参考に、`ublox_gps` パッケージを導入。依存関係 (`nmea_msgs`, `rtcm_msgs`) を解決し、ビルドは成功した。
        - しかし、`ros2 launch` でノードを起動すると、デバイスとの通信は確立できるものの、設定コマンドの送信に失敗 (`NACK: 0x06 / 0x8a`) する問題が繰り返し発生。
        - YAML設定ファイルで `config_on_startup: false` (パッシブモード) にするとノードは起動するが、デバイスがデフォルトで送信する情報が限定的で、衛星数などの診断に必要な情報が得られなかった。
        - `config_on_startup: true` に戻し、送信するメッセージを限定するなどの設定を試みたが、最終的に `Failed to read the GNSS config` という致命的なエラーでノードが起動しなくなった。
    - **方針2: `nmea_navsat_driver` パッケージの利用**
        - デバイスが標準的なNMEAメッセージを送信している可能性を考慮し、よりシンプルな `nmea_navsat_driver` を試した。
        - しかし、ノードのログで `codec can't decode byte 0xb5` というエラーが記録された。`0xb5` はu-bloxの独自バイナリ形式 **UBX** の開始バイトである。
        - これにより、**デバイスがデフォルトでNMEAではなくUBX形式でデータを送信している**ことが確定した。
    - **最終方針**: 
        - `ublox_gps` や `nmea_navsat_driver` などの既存パッケージでは、このGNSSデバイス (NEO-D9C) との安定した通信を確立するのが困難であると判断。
        - 唯一の成功実績である、**先輩が作成したROS1のコード (`gnss_evk.cpp`)** は、シリアル通信でNMEAメッセージを直接読み込んでいた。
        - この実績に基づき、既存パッケージの利用を断念し、**`gnss_evk.cpp` のロジックをROS2の作法で書き直し、新しいパッケージとして移植する**方針に決定した。

---

- **いつ (When):** 2025-11-05
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** 動的位置決め (DP) 機能の追加と手動操縦との切り替え機能の実装
- **なぜ (Why):** 船の定点保持機能を実現し、コントローラーのボタン操作で手動操縦とDPモードを切り替えられるようにするため。
    - **DPアルゴリズムのファイル (`dp_algorithms.hpp`)**: PID制御と2種類の推力配分アルゴリズム（シンプル版、角度制限版）を関数として実装。GNSSからの位置情報（ダミー）を元に定点保持する構造を追加。
    - **DPアロケータノード (`dp_allocator_node.cpp`)**: 
        - `/engage_station_keeping` および `/dp_mode_request` トピックを購読し、DPモードON/OFFとアルゴリズム選択を動的に制御。
        - `/gnss_pose` を購読し、現在位置とする。
        - DPモードがONの瞬間の現在位置を目標とし、PID制御で必要な推力を計算。
        - 選択されたアルゴリズムで推力配分を実施し、結果を `/thruster_command` (`azimuth_teleop/msg/AzimuthControl`) としてPublish。
    - **手動操縦ノード (`manual_teleop_node.cpp`)**: 
        - DPモードのオンオフとアルゴリズム選択用のボタンパラメータ (`button_dp_simple`, `button_dp_restricted`) を追加。
        - 対応するボタンが押された際に、`/engage_station_keeping` と `/dp_mode_request` をPublishするロジックを追加。
    - **F7インターフェースノード (`f7_interface_node.cpp`)**: 
        - `/engage_station_keeping` を購読し、DPモードON/OFF状態を把握。
        - 手動操縦からの指令 (`/azimuth_command`) とDPからの指令 (`/thruster_command`) の両方を購読。
        - DPモードの状態に応じて、どちらの指令をマイコンに送信するか切り替えるロジックを追加。
    - **ROS Launchファイル (`teleop.launch.py`)**: 
        - `dp_allocator_node` の起動設定を追記。
        - `manual_teleop_node` や `f7_interface_node` など、**既存のノードは変更せずそのまま**残した。
    - **ROS Package設定 (`package.xml`, `CMakeLists.txt`)**: 
        - `Eigen`ライブラリの依存関係を追加し、ビルドが通るように設定。
    - **Controller設定ファイル (`config/*.yaml`)**: 
        - HORI、8BitDo、BIGBIG WONの各コントローラー設定ファイルに、シンプル版DPと角度制限版DPを起動するボタンを割り当てた。

---

- **いつ (When):** 2025-11-05
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** 不要なlaunchファイルの削除
- **なぜ (Why):** `teleop.launch.py`が現在の主要なlaunchファイルであり、他のファイル（`remote_teleop.launch.py`, `teleop_system.launch.py`）は古いか、または`teleop.launch.py`で代替可能な機能しか持たないため、コードベースを整理するために削除した。

---

- **いつ (When):** 2025-11-03
- **誰が (Who):** Gemini
- **何を (What):** Bluetoothコントローラーの遠隔操作設定とROS 2リポジトリの問題解決
- **なぜ (Why):**
    - 手元のPCに接続したBluetoothコントローラーの操作を、SSH経由で模型船のPCに伝えるため、ROS 2の標準ネットワーク機能（Discovery Server）を利用する方針を決定。
    - その過程で、Discovery Serverを起動するためのツール (`fastdds-tools`) が見つからない、またはインストールできないという問題が発生。
    - **問題1: `fastdds discovery -s` コマンドが見つからない/エラー**
        - **原因**: Discovery Serverツールが未インストール。
        - **解決策**: `apt`でインストールを試みるも、ROS 2リポジトリがシステムに正しく設定されていないため失敗。
    - **問題2: ROS 2リポジトリが`apt`で認識されない**
        - **原因**: 以前のROS 2インストール時のリポジトリ設定が不完全または競合していた。
        - **解決策**:
            1.  ROS 2の公式GPGキーを再追加。
            2.  公式リポジトリ (`http://packages.ros.org/ros2/ubuntu jammy main`) を `/etc/apt/sources.list.d/ros2.list` に追加。
            3.  既存の競合するリポジトリ設定ファイル (`/etc/apt/sources.list.d/ros2.sources`) をリネームして無効化。
    - **問題3: 正しいパッケージ名が不明**
        - **原因**: リポジトリ設定後も `ros-humble-fast-dds-cli` が見つからず、パッケージ名が誤っていた。
        - **解決策**: `apt-cache search discovery` を実行し、正しいパッケージ名が `fastdds-tools` であることを特定。
    - **現在の状況**: `sudo apt install fastdds-tools` を実行する準備が整った。

---

- **いつ (When):** 2025-11-02
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** Added LED control feature.
- **なぜ (Why):** To allow controlling an LED on the Nucleo board via a joystick, the `manual_teleop_node` was modified to publish a `/led_toggle` message, and the `f7_interface_node` was updated to subscribe to this topic and send the LED state to the Nucleo board via UDP.

---

- **いつ (When):** 2025-10-31

- **いつ (When):** 2025-10-28
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** UDP通信不具合の最終調査と結論
- **なぜ (Why):**
    - ノートPCとSTM32間のUDP通信が確立できない問題について、ROS2 PC側の調査を再実施。
    - 低レイヤー担当からの報告を受け、PCのファイアウォール(`ufw`, `iptables`)が全許可状態であることをコマンドで確認。ソフトウェア的なブロックがないことを切り分けた。
    - `f7_interface_node`にエラーハンドリングを実装し、`sendto`システムコールがOSレベルでエラーを返していないことを確認。
    - `dmesg`コマンドのカーネルログを調査した結果、**USB-Ethernet変換アダプタが物理的に切断と再接続を繰り返している**ログを発見。
    - PCのUSBポートを変更しても同様の切断ログが記録されたため、PC本体のポート故障の可能性は低いと判断。
    - 以上のことから、**問題の原因はソフトウェアやドライバではなく、USB-Ethernet変換アダプタ、または関連するハブ/ケーブル等の物理的なハードウェア障害であると結論付けた。**
    - 今後の対応としては、これらのハードウェアを交換する必要がある。

- **いつ (When):** 2025-10-28
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** ROS2 PCからSTM32へのUDP通信の確立
- **なぜ (Why):**
    - `f7_interface_node.cpp`のソースコードを調査した結果、送信先IPアドレスが`192.168.1.100`にハードコードされていた。これは本来の送信先である`192.168.21.111`と異なっていたため、通信が失敗していた。
    - IPアドレスを`192.168.21.111`に修正し、`colcon build`でワークスペースを再ビルド。
    - `ros2 launch`でノードを起動したところ、Ethernetポートの通信アクティビティLEDの点滅が確認された。
    - これにより、ROS2 PCからSTM32へUDPパケットが正常に送信されている状態になったと判断。
    - Nucleoボード上のLEDに変化がないことから、今後の調査の焦点はSTM32側のUDP受信およびデータ処理プログラムとなる。

- **いつ (When):** 2025-10-27
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** STM32とROS2 PC間のUDP通信不具合に関する調査
- **なぜ (Why):**
    - 低レイヤー担当からの報告を受け、ROS2 PC側の接続性を調査した。
    - `ip a`コマンドで、PC側のIPアドレス(`192.168.21.100`)が正しく設定されていることを確認。
    - `ping`コマンドで、STM32(`192.168.21.111`)への疎通を確認。物理層・IP層での接続は問題ないことを切り分けた。
    - `nc`コマンドを使用し、仕様通りのUDPパケット(`0xAA55`ヘッダー)を送信したが、STM32からの応答はなかった。
    - ユーザーからの情報により、PC側の**ファイヤーウォールは無効**であることが確認済み。
    - この結果から、問題はSTM32側、特にUDPサーバーアプリケーションが正しく起動していない可能性が高いと推測される。
    - (補足: 当初`sudo`が必要なコマンドは中断していたが、ユーザーよりパスワード入力は問題ないとの情報を得たため、今後の調査では`nmap`等も有効な選択肢となる。)

- **いつ (When):** 2025-10-28
- **誰が (Who)::** Gemini (Gyaru-Agent)
- **何を (What):** `manual_teleop_node`のパラメータ化と複数コントローラー対応
- **なぜ (Why):**
    - 従来の`manual_teleop_node`は、HORIコントローラーのボタン・軸配置がC++ソースコード内にハードコードされており、他のコントローラーが使用できなかった。
    - この問題を解決するため、ノードを全面的に改修し、ボタン・軸・速度スケール等の設定をROSパラメータとして外部のYAMLファイルから読み込めるようにした。
    - `teleop.launch.py`が接続されたコントローラーのデバイス名を元に`hori.yaml`と`8bitdo.yaml`を自動で切り替えて読み込むように修正。
    - これにより、HORIコントローラーは従来の操作感を維持しつつ、8bitDo Microコントローラーでも「十字キーで移動」「L/Rボタンで回転」「速度半減」という要求仕様での操作を実現した。
    - 今後、新しいコントローラーを追加する際も、C++コードを変更することなくYAMLファイルを作成・編集するだけで対応可能になり、保守性が大幅に向上した。

---

- **いつ (When):** 2025-10-28
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** 8bitDoコントローラーのマッピング不具合を修正
- **なぜ (Why):**
    - `8bitdo.yaml`に設定した軸・ボタンのIDが、ユーザー提供のメモの解釈違いにより1ずつずれており、特に回転操作が機能しない問題が発生していた。
    - ユーザーからのフィードバックを受け、コントローラーの「N番目」という表記を正しいインデックス番号に修正。
    - これにより、8bitDoコントローラーが要求仕様通りに動作するようになった。

---

- **いつ (When):** 2025-10-31
- **誰が (Who):** Gemini (Gyaru-Agent)
- **何を (What):** `ros2 launch` 実行時の `evdev` ライブラリ不足エラーを解決
- **なぜ (Why):** `azimuth_teleop` パッケージの `teleop.launch.py` 実行時に `evdev` ライブラリが見つからないというエラーが発生したため、`pip install evdev` を実行してライブラリをインストールした。これにより、`ros2 launch` が正常に動作するようになった。