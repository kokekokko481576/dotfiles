#include "rclcpp/rclcpp.hpp"
#include "ublox_msgs/msg/nav_pvt.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "tf2/LinearMath/Quaternion.h"

class GnssConverterNode : public rclcpp::Node {
public:
    GnssConverterNode() : Node("gnss_converter_node") {
        navpvt_subscription_ = this->create_subscription<ublox_msgs::msg::NavPVT>(
            "/navpvt", 10, std::bind(&GnssConverterNode::navpvt_callback, this, std::placeholders::_1));
        gnss_pose_publisher_ = this->create_publisher<geometry_msgs::msg::PoseStamped>("/gnss_pose", 10);
    }

private:
    void navpvt_callback(const ublox_msgs::msg::NavPVT::SharedPtr msg) {
        // 測位状態が有効でない場合は処理しない
        if (msg->fix_type != 3) { // 3 = 3D-Fix
            return;
        }

        auto pose_msg = geometry_msgs::msg::PoseStamped();
        pose_msg.header.stamp = this->get_clock()->now();
        pose_msg.header.frame_id = "map"; // or "world"

        // 緯度経度を簡易的にx, yにマッピング
        // TODO: UTMなどの平面直角座標系に変換する
        pose_msg.pose.position.x = static_cast<double>(msg->lon) * 1e-7;
        pose_msg.pose.position.y = static_cast<double>(msg->lat) * 1e-7;
        pose_msg.pose.position.z = static_cast<double>(msg->height) * 1e-3; // mm to m

        // 進行方向(head_mot)をクォータニオンに変換
        // head_motはNED座標系（North-East-Down）での進行方向
        // ROSはENU座標系（East-North-Up）が一般的なので、変換が必要
        // head_mot [deg / 1e-5]
        double heading_deg = static_cast<double>(msg->heading) * 1e-5;
        // NED to ENU: heading_enu = 90 - heading_ned
        double heading_rad_enu = (90.0 - heading_deg) * M_PI / 180.0;

        tf2::Quaternion q;
        q.setRPY(0, 0, heading_rad_enu);
        pose_msg.pose.orientation.x = q.x();
        pose_msg.pose.orientation.y = q.y();
        pose_msg.pose.orientation.z = q.z();
        pose_msg.pose.orientation.w = q.w();

        gnss_pose_publisher_->publish(pose_msg);
    }

    rclcpp::Subscription<ublox_msgs::msg::NavPVT>::SharedPtr navpvt_subscription_;
    rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr gnss_pose_publisher_;
};

int main(int argc, char * argv[]) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<GnssConverterNode>());
    rclcpp::shutdown();
    return 0;
}
